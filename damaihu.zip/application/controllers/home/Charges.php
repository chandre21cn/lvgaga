<?php
/**
 *
 * 金额相关操作
 * @author Administrator
 *
 */
class Charges extends MY_Op
{
	public function PublishCash()
	{

	}

	public function AcceptCash()
	{

	}

	public function ChongZhi()
	{

	}
}

?>