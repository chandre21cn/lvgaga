<?php
class Working extends MY_Op
{
	public function AcceptWork()
	{

	}

	public function PublishWork()
	{

	}

	public function TaobaoWork()
	{

	}
}