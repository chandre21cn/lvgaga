<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Counting extends MY_Controller
{
	public function acceptCharges()
	{
	}
}