
</div>
	 </div>
	</div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/static/dist/js/bootstrap.min.js"></script>
  </body>
</html>