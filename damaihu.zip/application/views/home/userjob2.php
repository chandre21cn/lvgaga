<?php include"member_body.php";?>
<div id="_right">
	<div id="myjob">
	<div class="top">
		<div class="tiebuy">
			<h1>温馨提示：</h1>
			<p>1、接发平台信誉任务，必须完成或者取消后才可以更换。请根据自身情况进行接手！<br>
			2、任务完成后需要您返回到任务中心进行奖品认领，系统在完成任务后会发站内邮件通知，无论任务是否完成，任务进度将会在领取任务7天后凌晨自动清零，请您务必在此前领取奖励！<br>
			3、领取奖励时接发任务数量大于或者等于都可以，如果7天内某天或某几天小于任务数量，任务将失败。
			</p>
		</div>
	</div>
	<div class="member-job1">
		<h1><span>类型1</span>接发平台信誉任务</h1>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 5 位用户完成此任务

						<a class="a" href="javascript:;" type="1"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">5</span>个任务，接手<span class="li1">5</span>个任务，任务完成后，平台奖励您<span class="li1">4</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 1 位用户完成此任务

						<a class="a" href="javascript:;" type="2"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">10</span>个任务，接手<span class="li1">10</span>个任务，任务完成后，平台奖励您<span class="li1">8</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 0 位用户完成此任务

						<a class="a" href="javascript:;" type="3"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">20</span>个任务，接手<span class="li1">20</span>个任务，任务完成后，平台奖励您<span class="li1">16</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 0 位用户完成此任务

						<a class="a" href="javascript:;" type="4"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">40</span>个任务，接手<span class="li1">40</span>个任务，任务完成后，平台奖励您<span class="li1">32</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 3 位用户完成此任务

						<a class="a" href="javascript:;" type="5"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">5</span>个任务，接手<span class="li1">0</span>个任务，任务完成后，平台奖励您<span class="li1">5</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 3 位用户完成此任务

						<a class="a" href="javascript:;" type="6"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">10</span>个任务，接手<span class="li1">0</span>个任务，任务完成后，平台奖励您<span class="li1">10</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 1 位用户完成此任务

						<a class="a" href="javascript:;" type="7"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">40</span>个任务，接手<span class="li1">0</span>个任务，任务完成后，平台奖励您<span class="li1">40</span>个星星
			</li>
		</ul>
		<p></p>

		<ul>
			<li class="to1">
				<span class="li0">任务发不停，奖励送不断！</span>共有 1 位用户完成此任务

						<a class="a" href="javascript:;" type="8"></a>




			</li>
			<li>
				<span class="li1">此任务等待着接手...</span>
			</li>
			<li>
				您需要连续<span class="li1">7</span>天，每天发布<span class="li1">80</span>个任务，接手<span class="li1">0</span>个任务，任务完成后，平台奖励您<span class="li1">80</span>个星星
			</li>
		</ul>
		<p></p>


	</div>
	<!-- 职业刷客  -->
	<div class="member-job2">
		<div class="space10"></div>
		<ul id="userjob2">
		    <li class="to1">
		    	<span class="li0"><a name="#fa">任务接不停，奖励送不断！</a></span>
				<a class="aa" href="/#specialty"></a>
			</li>
			<li>
				<span class="li1">任务正在进行...</span>
			</li>
			<li>职业刷客在本周接手任务量达到<span class="li1">500</span>个，平台奖励您<span class="li1">100</span>星星</li>
		 </ul>
	</div>
</div>
</div>
</div>
<script>
$(function(){
	$('.user_left .renwu1').mouseover(function(){$('.user_left .left_alert').css('display','block');})
	$('.user_left .left_alert').mouseleave(function(){$('.user_left .left_alert').css('display','none');})
})
</script>
<?php include 'index_footer.php';?>