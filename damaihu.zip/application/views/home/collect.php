<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>淘宝刷收藏 - 大麦户信誉平台</title>
<link rel="shortcut icon" href="http://www.idc-hosting.com/favicon.ico">
<meta name="description" content="刷信誉安全吗?大麦户淘宝刷钻平台不仅给淘宝卖家提供淘宝刷信誉,淘宝刷信用,淘宝刷钻,还提供淘宝刷收藏,刷流量,淘宝代刷等增值服务,公司化运营,安全担保,让您的店铺好评如潮.登陆大麦户专业免费淘宝互刷信誉平台!">
<meta name="keywords" content="淘宝刷钻,淘宝刷钻平台,淘宝刷信誉,刷信誉,淘宝刷信用">
<link href="/static/css2/qq.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js2/jquery.js"></script>
<link href="/static/css2/main.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.js"></script>

<style type="text/css">
.kd a:hover { text-decoration:underline;}
</style>
<style type="text/css" charset="utf-8">/* See license.txt for terms of usage */
/** reset styling **/
.firebugResetStyles {
    z-index: 2147483646 !important;
    top: 0 !important;
    left: 0 !important;
    display: block !important;
    border: 0 none !important;
    margin: 0 !important;
    padding: 0 !important;
    outline: 0 !important;
    min-width: 0 !important;
    max-width: none !important;
    min-height: 0 !important;
    max-height: none !important;
    position: fixed !important;
    transform: rotate(0deg) !important;
    transform-origin: 50% 50% !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: transparent none !important;
    pointer-events: none !important;
    white-space: normal !important;
}

.firebugBlockBackgroundColor {
    background-color: transparent !important;
}

.firebugResetStyles:before, .firebugResetStyles:after {
    content: "" !important;
}
/**actual styling to be modified by firebug theme**/
.firebugCanvas {
    display: none !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.firebugLayoutBox {
    width: auto !important;
    position: static !important;
}

.firebugLayoutBoxOffset {
    opacity: 0.8 !important;
    position: fixed !important;
}

.firebugLayoutLine {
    opacity: 0.4 !important;
    background-color: #000000 !important;
}

.firebugLayoutLineLeft, .firebugLayoutLineRight {
    width: 1px !important;
    height: 100% !important;
}

.firebugLayoutLineTop, .firebugLayoutLineBottom {
    width: 100% !important;
    height: 1px !important;
}

.firebugLayoutLineTop {
    margin-top: -1px !important;
    border-top: 1px solid #999999 !important;
}

.firebugLayoutLineRight {
    border-right: 1px solid #999999 !important;
}

.firebugLayoutLineBottom {
    border-bottom: 1px solid #999999 !important;
}

.firebugLayoutLineLeft {
    margin-left: -1px !important;
    border-left: 1px solid #999999 !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.firebugLayoutBoxParent {
    border-top: 0 none !important;
    border-right: 1px dashed #E00 !important;
    border-bottom: 1px dashed #E00 !important;
    border-left: 0 none !important;
    position: fixed !important;
    width: auto !important;
}

.firebugRuler{
    position: absolute !important;
}

.firebugRulerH {
    top: -15px !important;
    left: 0 !important;
    width: 100% !important;
    height: 14px !important;
    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%13%88%00%00%00%0E%08%02%00%00%00L%25a%0A%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%04%F8IDATx%DA%EC%DD%D1n%E2%3A%00E%D1%80%F8%FF%EF%E2%AF2%95%D0D4%0E%C1%14%B0%8Fa-%E9%3E%CC%9C%87n%B9%81%A6W0%1C%A6i%9A%E7y%0As8%1CT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AATE9%FE%FCw%3E%9F%AF%2B%2F%BA%97%FDT%1D~K(%5C%9D%D5%EA%1B%5C%86%B5%A9%BDU%B5y%80%ED%AB*%03%FAV9%AB%E1%CEj%E7%82%EF%FB%18%BC%AEJ8%AB%FA'%D2%BEU9%D7U%ECc0%E1%A2r%5DynwVi%CFW%7F%BB%17%7Dy%EACU%CD%0E%F0%FA%3BX%FEbV%FEM%9B%2B%AD%BE%AA%E5%95v%AB%AA%E3E5%DCu%15rV9%07%B5%7F%B5w%FCm%BA%BE%AA%FBY%3D%14%F0%EE%C7%60%0EU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5JU%88%D3%F5%1F%AE%DF%3B%1B%F2%3E%DAUCNa%F92%D02%AC%7Dm%F9%3A%D4%F2%8B6%AE*%BF%5C%C2Ym~9g5%D0Y%95%17%7C%C8c%B0%7C%18%26%9CU%CD%13i%F7%AA%90%B3Z%7D%95%B4%C7%60%E6E%B5%BC%05%B4%FBY%95U%9E%DB%FD%1C%FC%E0%9F%83%7F%BE%17%7DkjMU%E3%03%AC%7CWj%DF%83%9An%BCG%AE%F1%95%96yQ%0Dq%5Dy%00%3Et%B5'%FC6%5DS%95pV%95%01%81%FF'%07%00%00%00%00%00%00%00%00%00%F8x%C7%F0%BE%9COp%5D%C9%7C%AD%E7%E6%EBV%FB%1E%E0(%07%E5%AC%C6%3A%ABi%9C%8F%C6%0E9%AB%C0'%D2%8E%9F%F99%D0E%B5%99%14%F5%0D%CD%7F%24%C6%DEH%B8%E9rV%DFs%DB%D0%F7%00k%FE%1D%84%84%83J%B8%E3%BA%FB%EF%20%84%1C%D7%AD%B0%8E%D7U%C8Y%05%1E%D4t%EF%AD%95Q%BF8w%BF%E9%0A%BF%EB%03%00%00%00%00%00%00%00%00%00%B8vJ%8E%BB%F5%B1u%8Cx%80%E1o%5E%CA9%AB%CB%CB%8E%03%DF%1D%B7T%25%9C%D5(%EFJM8%AB%CC'%D2%B2*%A4s%E7c6%FB%3E%FA%A2%1E%80~%0E%3E%DA%10x%5D%95Uig%15u%15%ED%7C%14%B6%87%A1%3B%FCo8%A8%D8o%D3%ADO%01%EDx%83%1A~%1B%9FpP%A3%DC%C6'%9C%95gK%00%00%00%00%00%00%00%00%00%20%D9%C9%11%D0%C0%40%AF%3F%EE%EE%92%94%D6%16X%B5%BCMH%15%2F%BF%D4%A7%C87%F1%8E%F2%81%AE%AAvzr%DA2%ABV%17%7C%E63%83%E7I%DC%C6%0Bs%1B%EF6%1E%00%00%00%00%00%00%00%00%00%80cr%9CW%FF%7F%C6%01%0E%F1%CE%A5%84%B3%CA%BC%E0%CB%AA%84%CE%F9%BF)%EC%13%08WU%AE%AB%B1%AE%2BO%EC%8E%CBYe%FE%8CN%ABr%5Dy%60~%CFA%0D%F4%AE%D4%BE%C75%CA%EDVB%EA(%B7%F1%09g%E5%D9%12%00%00%00%00%00%00%00%00%00H%F6%EB%13S%E7y%5E%5E%FB%98%F0%22%D1%B2'%A7%F0%92%B1%BC%24z3%AC%7Dm%60%D5%92%B4%7CEUO%5E%F0%AA*%3BU%B9%AE%3E%A0j%94%07%A0%C7%A0%AB%FD%B5%3F%A0%F7%03T%3Dy%D7%F7%D6%D4%C0%AAU%D2%E6%DFt%3F%A8%CC%AA%F2%86%B9%D7%F5%1F%18%E6%01%F8%CC%D5%9E%F0%F3z%88%AA%90%EF%20%00%00%00%00%00%00%00%00%00%C0%A6%D3%EA%CFi%AFb%2C%7BB%0A%2B%C3%1A%D7%06V%D5%07%A8r%5D%3D%D9%A6%CAu%F5%25%CF%A2%99%97zNX%60%95%AB%5DUZ%D5%FBR%03%AB%1C%D4k%9F%3F%BB%5C%FF%81a%AE%AB'%7F%F3%EA%FE%F3z%94%AA%D8%DF%5B%01%00%00%00%00%00%00%00%00%00%8E%FB%F3%F2%B1%1B%8DWU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*UiU%C7%BBe%E7%F3%B9%CB%AAJ%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5*%AAj%FD%C6%D4%5Eo%90%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5%86%AF%1B%9F%98%DA%EBm%BBV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%AD%D6%E4%F58%01%00%00%00%00%00%00%00%00%00%00%00%00%00%40%85%7F%02%0C%008%C2%D0H%16j%8FX%00%00%00%00IEND%AEB%60%82") repeat-x !important;
    border-top: 1px solid #BBBBBB !important;
    border-right: 1px dashed #BBBBBB !important;
    border-bottom: 1px solid #000000 !important;
}

.firebugRulerV {
    top: 0 !important;
    left: -15px !important;
    width: 14px !important;
    height: 100% !important;
    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0E%00%00%13%88%08%02%00%00%00%0E%F5%CB%10%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%06~IDATx%DA%EC%DD%D1v%A20%14%40Qt%F1%FF%FF%E4%97%D9%07%3BT%19%92%DC%40(%90%EEy%9A5%CB%B6%E8%F6%9Ac%A4%CC0%84%FF%DC%9E%CF%E7%E3%F1%88%DE4%F8%5D%C7%9F%2F%BA%DD%5E%7FI%7D%F18%DDn%BA%C5%FB%DF%97%BFk%F2%10%FF%FD%B4%F2M%A7%FB%FD%FD%B3%22%07p%8F%3F%AE%E3%F4S%8A%8F%40%EEq%9D%BE8D%F0%0EY%A1Uq%B7%EA%1F%81%88V%E8X%3F%B4%CEy%B7h%D1%A2E%EBohU%FC%D9%AF2fO%8BBeD%BE%F7X%0C%97%A4%D6b7%2Ck%A5%12%E3%9B%60v%B7r%C7%1AI%8C%BD%2B%23r%00c0%B2v%9B%AD%CA%26%0C%1Ek%05A%FD%93%D0%2B%A1u%8B%16-%95q%5Ce%DCSO%8E%E4M%23%8B%F7%C2%FE%40%BB%BD%8C%FC%8A%B5V%EBu%40%F9%3B%A72%FA%AE%8C%D4%01%CC%B5%DA%13%9CB%AB%E2I%18%24%B0n%A9%0CZ*Ce%9C%A22%8E%D8NJ%1E%EB%FF%8F%AE%CAP%19*%C3%BAEKe%AC%D1%AAX%8C*%DEH%8F%C5W%A1e%AD%D4%B7%5C%5B%19%C5%DB%0D%EF%9F%19%1D%7B%5E%86%BD%0C%95%A12%AC%5B*%83%96%CAP%19%F62T%86%CAP%19*%83%96%CA%B8Xe%BC%FE)T%19%A1%17xg%7F%DA%CBP%19*%C3%BA%A52T%86%CAP%19%F62T%86%CA%B0n%A9%0CZ%1DV%C6%3D%F3%FCH%DE%B4%B8~%7F%5CZc%F1%D6%1F%AF%84%F9%0F6%E6%EBVt9%0E~%BEr%AF%23%B0%97%A12T%86%CAP%19%B4T%86%CA%B8Re%D8%CBP%19*%C3%BA%A52huX%19%AE%CA%E5%BC%0C%7B%19*CeX%B7h%A9%0C%95%E1%BC%0C%7B%19*CeX%B7T%06%AD%CB%5E%95%2B%BF.%8F%C5%97%D5%E4%7B%EE%82%D6%FB%CF-%9C%FD%B9%CF%3By%7B%19%F62T%86%CA%B0n%D1R%19*%A3%D3%CA%B0%97%A12T%86uKe%D0%EA%B02*%3F1%99%5DB%2B%A4%B5%F8%3A%7C%BA%2B%8Co%7D%5C%EDe%A8%0C%95a%DDR%19%B4T%C66%82fA%B2%ED%DA%9FC%FC%17GZ%06%C9%E1%B3%E5%2C%1A%9FoiB%EB%96%CA%A0%D5qe4%7B%7D%FD%85%F7%5B%ED_%E0s%07%F0k%951%ECr%0D%B5C%D7-g%D1%A8%0C%EB%96%CA%A0%A52T%C6)*%C3%5E%86%CAP%19%D6-%95A%EB*%95q%F8%BB%E3%F9%AB%F6%E21%ACZ%B7%22%B7%9B%3F%02%85%CB%A2%5B%B7%BA%5E%B7%9C%97%E1%BC%0C%EB%16-%95%A12z%AC%0C%BFc%A22T%86uKe%D0%EA%B02V%DD%AD%8A%2B%8CWhe%5E%AF%CF%F5%3B%26%CE%CBh%5C%19%CE%CB%B0%F3%A4%095%A1%CAP%19*Ce%A8%0C%3BO*Ce%A8%0C%95%A12%3A%AD%8C%0A%82%7B%F0v%1F%2FD%A9%5B%9F%EE%EA%26%AF%03%CA%DF9%7B%19*Ce%A8%0C%95%A12T%86%CA%B8Ze%D8%CBP%19*Ce%A8%0C%95%D1ae%EC%F7%89I%E1%B4%D7M%D7P%8BjU%5C%BB%3E%F2%20%D8%CBP%19*Ce%A8%0C%95%A12T%C6%D5*%C3%5E%86%CAP%19*Ce%B4O%07%7B%F0W%7Bw%1C%7C%1A%8C%B3%3B%D1%EE%AA%5C%D6-%EBV%83%80%5E%D0%CA%10%5CU%2BD%E07YU%86%CAP%19*%E3%9A%95%91%D9%A0%C8%AD%5B%EDv%9E%82%FFKOee%E4%8FUe%A8%0C%95%A12T%C6%1F%A9%8C%C8%3D%5B%A5%15%FD%14%22r%E7B%9F%17l%F8%BF%ED%EAf%2B%7F%CF%ECe%D8%CBP%19*Ce%A8%0C%95%E1%93~%7B%19%F62T%86%CAP%19*Ce%A8%0C%E7%13%DA%CBP%19*Ce%A8%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4%AE%A4%F5%25%C0%00%DE%BF%5C'%0F%DA%B8q%00%00%00%00IEND%AEB%60%82") repeat-y !important;
    border-left: 1px solid #BBBBBB !important;
    border-right: 1px solid #000000 !important;
    border-bottom: 1px dashed #BBBBBB !important;
}

.overflowRulerX > .firebugRulerV {
    left: 0 !important;
}

.overflowRulerY > .firebugRulerH {
    top: 0 !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.fbProxyElement {
    position: fixed !important;
    pointer-events: auto !important;
}
</style></head>

<body>
<script src="/ServiceQQ.htm"></script><div style="top: -194px; left: auto; right: 82.5px; position: fixed;" class="service">		<div class="info" style="display: none;">			<div class="i-h">				<span class="s-h1">联系我们</span>				<div class="s-h-ico"><i class="ico circle-qq"></i><i class="ico circle-phone"></i></div>			</div>			<div class="i-1 s-title">网商业务咨询</div>			<div class="i-2"><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes">客服小麦</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes"><img src="/pa.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes">客服小芸</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes"><img src="/pa_002.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes">客服小粉</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes"><img src="/pa_003.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes">客服小黄</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes"><img src="/pa_004.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label>				<span class="s-title">网商互动QQ群</span>			</div>			<div class="i-3">				<label class="qq-indent">					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7">140904771</a>					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7"><img src="/group.png" alt="大麦户刷钻平台26群" title="大麦户刷钻平台26群" border="0"></a>				</label>			</div>		</div>		<div class="box">			<div class="s-h">				<div class="ico qq"></div>				<div class="t">					<i class="ico left-arrow"></i>					<i class="ico stext"></i>				</div>			</div>			<div class="s-f"><a href="#">返回顶部</a><i class="ico top-arrow"></i></div>		</div>	</div>
	<!--头部开始-->
	<style>
#dmh_head {background: #EFF6FE;border-bottom: 1px solid #DBEBFA;height: 25px;left: 0;position: fixed;width: 100%;z-index: 9999;}
#dmh_head .kd {position: relative;}
#dmh_head .kd, #m_banner .kd {margin: 0 auto;width: 980px;}
#dmh_head .kmain {position: absolute;top: 0;width: 898px;}
#dmh_head .hy {float: left;}
#dmh_head .kd .dmhtel {background: url("/static/image2/dmhtel.png") no-repeat scroll 7px center transparent;float: left;height: 22px;padding-left: 25px;width: 36px;}
#dmh_head .hy a {color: #1595DE;margin: 0 5px;}
#dmh_head .hy a.col3 {color: #666666;margin: 0 10px;}
#dmh_head .top_btn {color: #1595DE;float: right;}
#dmh_head .top_btn a {color: #1595DE;margin: 0 10px;}
#dmh_head .menu_qq {text-align: right;}
#dmh_head .menu_qq a {color: #1595DE;font-family: Tahoma,​Helvetica,​Arial,​宋体;font-size: 12px;padding-left: 26px;}
#dmh_head .menu_qq .qq_help {background: url("/static/image2/tx_ico.gif") no-repeat scroll 0 -958px transparent;}
#dmh_head .help_down {background: none repeat scroll 0 0 #FFFFFF;border: 3px solid #7FC3F4;padding: 0 10px;position: absolute;right: 0;top: 25px;width: 500px;z-index: 9999;height:255px;*height:270px;}
#dmh_head .help_down ul {border-bottom: 1px dashed #DDDDDD;padding-left: 10px;padding-top: 6px;}
#dmh_head a:hover{color:#FE5500}
#dmh_head b{color:#FE5500}
#dmh_head .quick-menu {margin: 2px 0 0 0;}
#dmh_head .quick-menu li.menu-item {padding: 1px 0 0;position: relative;margin-right: 1px;}
#dmh_head .quick-menu li {background-position: right 6px;float: left;margin-left: -1px;background:none;border:1px solid #EFF6FE;}
#menu-0{display:none;}
#dmh_head .menu {position: relative;float: left;line-height: 140%;}
#dmh_head .menu-hd {cursor: pointer;height: 20px;padding: 1px 22px 0 16px;position: relative;z-index: 10002;}
#dmh_head .menu-hd b {border-color: #666666 #EFF6FE #EFF6FE;border-style: solid;border-width: 4px;font-size: 0;height: 0;line-height: 0;position: absolute;right: 10px;top: 6px;transition: transform 0.2s ease-in 0s;width: 0;}
/*针对客服帮助*/
#dmh_head .help_down {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 3px solid #7FC3F4;
    height:195px;
    padding: 0 10px;
    position: absolute;
    right: 0;
    top: 25px;
    width: 500px;
    z-index: 9999;
}
</style>
<div id="dmh_head">
	<div class="kd">
	    <div class="kmain">
			<div class="hy">


				<div style="float:left;">

					<span style="color:#666">亲，欢迎来到{webName}！请</span>
					<a href="http://www.idc-hosting.com/user/login/" class="chengse">登录</a>
					<a href="http://www.idc-hosting.com/user/reg/" class="lvse">免费注册</a>
				</div>

			</div>
			<div class="top_btn">

				<ul class="quick-menu">
					<a href="http://www.idc-hosting.com/user/reg/" style="float:left;margin-top: -1px;"><b>新手帮助</b></a>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/html/express/" style="width:50px;margin:0;" class="menu-hd" tabindex="0">帮助中心<b></b></a>
							<div style="width: 105px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/diagram/index/">图文实录教程</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskout/">我是发布方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskin/">我是接手方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/bilking/">防骗小课堂</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/help/selfservice/" style="width:52px;margin:0;" class="menu-hd" tabindex="0">账号设置<b></b></a>
							<div style="width: 90px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回密码</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回操作码</a>
								   <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/">更多操作</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<a href="http://www.idc-hosting.com/rank.html" style="margin-top: -2px;">排行榜</a>
				</ul>

			</div>
		</div>

		<div class="menu_qq">
			<a class="qq_help" onmouseover="showcsqq();" href="javascript:;">客服帮助</a>
		</div>
		<div id="service_qq" class="help_down" style="display:none;"></div>
	</div>
</div>
<script>
$(function(){
	$(".menu-item .menu-hd").hover(function(){
		$(this).next('#menu-0').show();
		$(this).children('b').css({borderColor:'#666666 white white',transform:'rotate(180deg',transformOrigin:'50% 30% 0px'});
		$(this).parents(".menu-item").css({background:'rgb(255, 255, 255)',border:'1px solid rgb(191, 191, 191)'})
	});
	$(".menu-item .menu").mouseleave(function(){
		$(this).children('#menu-0').hide();
		$(this).children('.menu-hd').children('b').css({borderColor:'#666666 #EFF6FE #EFF6FE',transform:'none',transformOrigin:'none'});
		$(this).parent(".menu-item").css({background:'none',border:'1px solid #EFF6FE'})
	});
})
</script>
	<!--logo开始-->
	<div id="m_logo">
		<a href="http://www.idc-hosting.com/" class="logo"><img src="/static/image2/head_logo.png" alt="大麦户_淘宝刷信誉"></a>
		<a href="http://www.idc-hosting.com/fuwu/video/" class="gg" target="_blank"><img src="/static/image2/ddd.gif" alt="视频教程" title="视频教程" border="0" height="67" width="689"></a>
	</div>
	<!--菜单开始-->
<div id="m_menu" style="position:relative;">
	<div class="menu_nav">
		<div class="m_menu_nav">
			<ul>
			<?php include "menu.php"; ?>
			</ul>
		</div>
	</div>
</div>
	<!--main star-->
 <div id="content">
		<div style="margin-top:15px;float:left;"><img src="/static/image2/sc_banner.jpg" height="236" width="999"></div>
		<form  id="commentForm">
<table class="scly_scbk" cellpadding="0" cellspacing="0" border="0" width="490">
<tbody><tr>
			<td colspan="2" class="scly_gmsc" height="50">购买收藏</td>
    </tr>
		  <tr>
			<td align="right" height="45" width="170">宝贝或店铺地址：http://</td>
			<td><input name="cs_url" id="cs_url" class="scly_bk1" type="text"></td>
		  </tr>
		  <tr>
			<td align="right" height="45">收藏标签：</td>
			<td><input name="cs_mark" id="cs_mark" maxlength="62" class="scly_bk2" type="text"></td>
		  </tr>
		  <tr>
			<td align="right" height="30">&nbsp;</td>
			<td valign="top">标签最多<span class="chengse2">3</span>个(每条<span class="chengse2"><strong>10</strong></span>个字内)，以空格区分</td>
    </tr>
		  <tr>
			<td align="right" height="45">购买数量：</td>
			<td><input name="nums" class="scly_bk3" id="nums" maxlength="5" type="text">每个收藏只需0.1个麦点&nbsp;需要麦点：<span class="chengse2"><strong id="collect_price">0.00</strong></span></td>
    </tr>
		  <tr>
			<td colspan="2" height="70"><input class="scly_ljgm" type="submit"></td>
		  </tr>
  </tbody></table>
  </form>
<input name="hash2" value="MjY2OHdRSjZtZTRqUVN1UklFWDNlejBzRlhTRkhSRW9OS2QxSnJ6MFBWZmthc0FaL2lOVjJZRjhabWZTN3FnYVVhelJia280NEd3Mi9TNmlzdw==" type="hidden">
	    <table class="scly_scbk" style="margin-left:15px;" cellpadding="0" cellspacing="0" border="0" width="490">
          <tbody><tr>
            <td colspan="2" class="scly_gmll" height="50">购买流量</td>
          </tr>
          <tr>
            <td align="right" height="45" width="115">购买IP数量：</td>
            <td><select name="ips" id="ips" onchange="get_total_price()">
            <?php foreach ($data as $_k=>$v):
				$dataTmp = unserialize($v->eve);
            ?>
			  <option selected="selected" value="200"><?php echo $dataTmp['l']?>IP/<?php echo $dataTmp['t']?>小时内达到，价格：<?php echo $dataTmp['m']?>个麦点</option>
			<?php endforeach;?>
            </select></td>
          </tr>
          <tr>
            <td align="right" height="45">IP流量地址：</td>
            <td><input name="url" id="url" class="scly_bk1" value="http://" type="text"></td>
          </tr>
          <tr>
            <td align="right" height="30">&nbsp;</td>
            <td valign="top">需要麦点：<span class="chengse2"><strong id="total_price_show">3</strong></span></td>
          </tr>
		  <tr id="span_days">
                <td align="right" height="30">持续天数：</td>
                <td><input name="days" value="1" checked="checked" onclick="get_total_price()" type="radio">
                  持续1天
                    <input name="days" value="7" onclick="get_total_price()" type="radio">
持续7天
<input name="days" value="30" onclick="get_total_price()" type="radio">
持续30天</td>
              </tr>
          <tr>
            <td align="right" height="45"></td>
            <td><a href="javascript:;" onclick="function_set_adv()" id="open_adv" class="lanse2">设置高级流量</a></td>
          </tr>
          <tr>
			<td colspan="2"><table id="set_adv" style="display:none;border:1px  solid #ddd; width:470px; margin:0 auto;" cellpadding="0" cellspacing="0" align="center" border="0">
             <tbody><tr>
                <td align="right" height="30">高级设置：<input name="need_adv" id="need_adv" value="0" type="hidden"></td>
                <td><p>
                  <label><input name="adv_seting[]" id="adv_seting_1" value="1" onclick="function_need_adv()" type="checkbox">自定义流量投放时间</label>
                  &nbsp;&nbsp;
                  <label><input name="adv_seting[]" id="adv_seting_2" value="2" onclick="function_need_adv()" type="checkbox">自定义PV:IP的倍数</label></p>
                  &nbsp;&nbsp;
				  <p>
                  <label><input name="adv_seting[]" id="adv_seting_3" value="3" onclick="function_need_adv()" type="checkbox">自定义投放地区</label>
                  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                  <label style="display:none"><input name="adv_seting[]" id="adv_seting_5" value="5" onclick="function_need_adv()" type="checkbox">自定义访问来源</label></p></td>
              </tr>
			  <tr id="span_cut_time" style="display:none;">
          <td align="right" bgcolor="#FFFFFF">&nbsp;&nbsp;自定义时间：</td>
          <td bgcolor="#FFFFFF">
          <label>开始时间：<input name="start_time" id="start_time" value="2014-04-30 00:26:45" class="it date-pick1 q b" style="cursor: hand;" onchange="get_total_price()" type="text"></label><br>
          <label>结束时间：<input name="end_time" id="end_time" value="2014-04-30 00:26:45" class="it date-pick2 q b" style="cursor: hand;" onchange="get_total_price()" type="text"> </label><br>（此服务选择后价格会提高20%）

          </td>
        </tr>
        <tr id="span_cut_pvs" style="display:none;">
          <td align="right" bgcolor="#FFFFFF" valign="top">&nbsp;&nbsp;自定义PV：</td>
          <td bgcolor="#FFFFFF"><label>
            <input name="pvs" id="pvs" value="1" size="2" maxlength="3" onchange="get_total_price()" type="text"> </label>
			<br>（PV:IP的倍数，如不太明白，可以不管，<br>使用默认值， 此服务选择后价格会有相应的提高，<br> PV为2时加10%，3加30%，4加200%，5加225%，<br>6加250%，7加300%，<br>8加325%，9加350%，以此类推）
		 </td>
        </tr>
        <tr id="span_cut_location" style="display:none;">
          <td align="right" bgcolor="#FFFFFF">&nbsp;&nbsp;自定义地区:&nbsp;</td>
          <td bgcolor="#FFFFFF">
          	<input name="province[]" value="北京" id="pprov1" onclick="get_total_price()" type="checkbox">
            <label for="pprov01">北京</label>

            <input name="province[]" value="上海" id="pprov2" onclick="get_total_price()" type="checkbox">
            <label for="pprov02">上海</label>

            <input name="province[]" value="天津" id="pprov3" onclick="get_total_price()" type="checkbox">
            <label for="pprov03">天津</label>

            <input name="province[]" value="重庆" id="pprov4" onclick="get_total_price()" type="checkbox">
            <label for="pprov04">重庆</label>

            <input name="province[]" value="河北" id="pprov5" onclick="get_total_price()" type="checkbox">
            <label for="pprov05">河北</label>

            <input name="province[]" value="山西" id="pprov6" onclick="get_total_price()" type="checkbox">
            <label for="pprov06">山西</label>
            <br>
            <input name="province[]" value="内蒙" id="pprov7" onclick="get_total_price()" type="checkbox">
            <label for="pprov07">内蒙</label>

            <input name="province[]" value="辽宁" id="pprov8" onclick="get_total_price()" type="checkbox">
            <label for="pprov08">辽宁</label>


            <input name="province[]" value="吉林" id="pprov9" onclick="get_total_price()" type="checkbox">
            <label for="pprov09">吉林</label>

            <input name="province[]" value="新疆" id="pprov10" onclick="get_total_price()" type="checkbox">
            <label for="pprov10">新疆</label>

            <input name="province[]" value="江苏" id="pprov11" onclick="get_total_price()" type="checkbox">
            <label for="pprov11">江苏</label>

            <input name="province[]" value="浙江" id="pprov12" onclick="get_total_price()" type="checkbox">
            <label for="pprov12">浙江</label>
             <br>
            <input name="province[]" value="安徽" id="pprov13" onclick="get_total_price()" type="checkbox">
            <label for="pprov13">安徽</label>


            <input name="province[]" value="福建" id="pprov14" onclick="get_total_price()" type="checkbox">
            <label for="pprov14">福建</label>

            <input name="province[]" value="江西" id="pprov15" onclick="get_total_price()" type="checkbox">
            <label for="pprov15">江西</label>

            <input name="province[]" value="山东" id="pprov16" onclick="get_total_price()" type="checkbox">
            <label for="pprov16">山东</label>


            <input name="province[]" value="河南" id="pprov17" onclick="get_total_price()" type="checkbox">
            <label for="pprov17">河南</label>

            <input name="province[]" value="湖北" id="pprov18" onclick="get_total_price()" type="checkbox">
            <label for="pprov18">湖北</label>
             <br>
            <input name="province[]" value="湖南" id="pprov19" onclick="get_total_price()" type="checkbox">
            <label for="pprov19">湖南</label>

            <input name="province[]" value="广东" id="pprov20" onclick="get_total_price()" type="checkbox">
            <label for="pprov20">广东</label>

            <input name="province[]" value="广西" id="pprov21" onclick="get_total_price()" type="checkbox">
            <label for="pprov21">广西</label>

            <input name="province[]" value="海南" id="pprov22" onclick="get_total_price()" type="checkbox">
            <label for="pprov22">海南</label>

            <input name="province[]" value="贵州" id="pprov23" onclick="get_total_price()" type="checkbox">
            <label for="pprov23">贵州</label>

            <input name="province[]" value="四川" id="pprov24" onclick="get_total_price()" type="checkbox">
            <label for="pprov24">四川</label>


              <br>
            <input name="province[]" value="云南" id="pprov25" onclick="get_total_price()" type="checkbox">
            <label for="pprov25">云南</label>

            <input name="province[]" value="西藏" id="pprov26" onclick="get_total_price()" type="checkbox">
            <label for="pprov26">西藏</label>

            <input name="province[]" value="陕西" id="pprov27" onclick="get_total_price()" type="checkbox">
            <label for="pprov27">陕西</label>

            <input name="province[]" value="甘肃" id="pprov28" onclick="get_total_price()" type="checkbox">
            <label for="pprov28">甘肃</label>

            <input name="province[]" value="青海" id="pprov29" onclick="get_total_price()" type="checkbox">
            <label for="pprov29">青海</label>

            <input name="province[]" value="宁夏" id="pprov30" onclick="get_total_price()" type="checkbox">
            <label for="pprov30">宁夏</label>
             <br>
            <input name="province[]" value="台湾" id="pprov31" onclick="get_total_price()" type="checkbox">
            <label for="pprov31">台湾</label>

            <input name="province[]" value="香港" id="pprov32" onclick="get_total_price()" type="checkbox">
            <label for="pprov32">香港</label>


            <input name="province[]" value="澳门" id="pprov33" onclick="get_total_price()" type="checkbox">
            <label for="pprov33">澳门</label>

            <input name="province[]" value="黑龙" id="pprov34" onclick="get_total_price()" type="checkbox">
            <label for="pprov34">黑龙江</label>
            <br>（此服务选择后价格会提高3倍）
                        </td>
        </tr>
            <tr id="span_cut_referer" style="display:none;">
          <td align="right" bgcolor="#FFFFFF" width="90">&nbsp;&nbsp;自定义访问来源：</td>
          <td bgcolor="#FFFFFF">
          <input name="url_referer[]" size="30" type="text"><br>
          <input name="url_referer[]" size="30" type="text"><br>
          <input name="url_referer[]" size="30" type="text"><br>
          <input name="url_referer[]" size="30" type="text"><br>

          （来源地址请填写浏览器http地址，此服务选择后价格会提高1倍，最多6个来源，最少一个，请确保来源地址能打开！）
          </td>
        </tr>
            </tbody></table></td>
          </tr>
          <tr>
            <td colspan="2" height="55"><input name="total_price" id="total_price" value="0" type="hidden"><input name="day" id="day" value="1" type="hidden"><input class="scly_ljgm" type="submit"></td>
          </tr>
        </tbody></table>
<div class="cle"></div>
	<table class="scly_bk4" cellpadding="0" cellspacing="0" border="0" width="490">
		  <tbody><tr>
			<td class="scly_tit" align="center" height="37" valign="middle">最近购买</td>
			<td class="scly_tit" align="center" valign="middle" width="10%">数量</td>
			<td class="scly_tit" align="center" valign="middle" width="22%">处理时间</td>
			<td class="scly_tit" align="center" valign="middle" width="32%">操作</td>
		  </tr>

  </tbody></table>

        <table class="scly_bk4" style="margin-left:15px;" cellpadding="0" cellspacing="0" border="0" width="490">
          <tbody><tr>
            <td class="scly_tit" align="center" height="37" valign="middle">最近购买</td>
            <td class="scly_tit" align="center" valign="middle" width="17%">数量</td>
            <td class="scly_tit" align="center" valign="middle" width="22%">处理时间</td>
            <td class="scly_tit" align="center" valign="middle" width="22%">操作</td>
          </tr>

  </tbody></table>
  <div class="cle"></div>
        <table class="scly_bk4" cellpadding="0" cellspacing="0" border="0" width="490">
          <tbody><tr>
            <td class="scly_tit" style="text-indent:24px;" align="left" height="37" valign="middle">购买收藏常见问题</td>
          </tr>
          <tr>
            <td class="scly_wtbg" style="padding:20px 25px;" align="left" height="37" valign="top">
			<p class="scly_tit2">购买收藏后是一下全到吗?</p>
			答：购买后可能需要24-48小时才会进行哦，敬请耐心等待。<br>
			<p class="scly_tit2">我的网店有多少信誉时就该刷收藏了呢？</p>
			答：卖家信誉在十以上就可以开始了，最晚在卖家信誉到100之前也要开始了；<br>
			<p class="scly_tit2">我的网店大概需要刷多少收藏是合理的呢？</p>
			答：这个要根据您网店当前的信誉度来决定，一般淘宝上收藏数是卖家信誉度的：10%--85%之间为一个比较合乎逻辑的范围；当然最合理的范围是20%-55%； 举例说明您现在的卖家信誉度是：100 那么您对应网店的合理收藏人气应该是：20-55个;<br>			</td>
          </tr>
        </tbody></table>
        <table class="scly_bk4" style="margin-left:15px;" cellpadding="0" cellspacing="0" border="0" width="490">
          <tbody><tr>
            <td class="scly_tit" style="text-indent:24px;" align="left" height="37" valign="middle">购买流量常见问题</td>
          </tr>
          <tr>
            <td class="scly_wtbg" style=" background:none;padding:20px 25px;" align="left" height="37" valign="top">
			<p class="scly_tit2">购买流量后是一下全到吗?</p>
              答：在您成功订购并通过核审后24小时内到达您的指定地址<br>
              <p class="scly_tit2">一天需要买多少流量合适呢？</p>
              答：首先保证你每天的成交单数（包括刷信誉）与当日的流量IP比例为1-3%，并且在以后最好也不要停止购买流量。我们建议一红星卖家从200流量开始买起，200为一个档次增加，循序渐进。<br>
			  <p class="scly_tit3"></p>
			  淘宝浏览量也称作淘宝浏览次数，淘宝浏览量直接影响商品的排名，浏览量高了以后如果搜索时按“人气”排的话就会排的前点，这样看的人多了卖的也可能就更多！
排名和搜索会靠前，浏览量多了，意味着你的店人气高了，那销量一般会跟着升起来的；对于经常刷信誉的我们来说，淘宝流量=淘宝来路，如果刷流量的话，你的来路从此就不会单一，<strong>最重要的是这样来路都是真实的ip，量子统计均可查，这样的话就能非常有效的避免降权。</strong> </td>
          </tr>
        </tbody></table>
</div>
<div class="cle"></div>
<div id="footer">
  <p><span class="chengse">官方QQ群：<span class="web_qq">147898283</span><span style="display:none;" class="quick_qq"><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img src="/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群" border="0"></a></span></span> （加群请注明大麦户）</p>
		<p class="lanse"><a href="http://www.idc-hosting.com/info/aboutus.html">关于我们</a>|<a href="http://www.idc-hosting.com/info/contactus.html">联系我们</a>|<a href="http://www.idc-hosting.com/info/duty.html">服务条款</a>|<a href="http://www.idc-hosting.com/info/map.html">网站地图</a>|<a href="http://www.yaodamai.com/" target="_blank">淘宝信誉查询</a> </p>
  <!-- <p style="text-align:center;"><a id='___szfw_logo___' href='https://search.szfw.org/cert/l/CX20130730002661002730' target='_blank'><img height='32' src='https://search.szfw.org/cert.png?l=CX20130730002661002730'></a></p> -->
  <p class="lanse">客户服务热线：4006079159   Copyright © 2012-2020 Damaihu.com All RightsReserved    大麦户版权所有 粤ICP备13037934号<span style="display:none;">
</span></p>
</div>

<script type="text/javascript" src="/static/js2/common.js"></script>
<script type="text/javascript">
var webqq = 147898283;
var webnoticeurl = "";
var webnoticetit = "";
var quick_qq = '<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img border="0" src="http://pub.idqqimg.com/wpa/static/image2/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群"></a>';
$('.web_qq').hover(function(){
    $('.quick_qq').show();
});
</script>
<script type="text/javascript">
$('.service').css({
	    'top': $(window).height()-508,
		'left':"auto",
	    'right': ($(window).width() - 1000)>0?($(window).width() - 1000)/2-$('.service').width()-5:0 ,
		'position':"fixed"
	});
</script>
<script type="text/javascript" src="/static/js2/service.js"></script>
<script type="text/javascript" src="/static/js2/collect.js"></script>

</body></html>