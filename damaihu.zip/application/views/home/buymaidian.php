<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>购买麦点，轻松发任务 - 大麦户网商互动平台领跑者，接任务赚佣金，发任务赚信誉，让您生意大卖。</title>
<link rel="shortcut icon" href="http://www.idc-hosting.com/favicon.ico">
<meta name="description" content="购买麦点，轻松发任务 - 大麦户互动平台网是国内领先诚信安全淘宝担保交易平台,免费提供安全真实的快递单号,全程模拟真实交易,确保您店铺每一笔信用都是真实交易,快速提升网店收益.">
<meta name="keywords" content="淘宝刷钻,淘宝刷钻平台,淘宝刷信誉,刷信誉,淘宝刷信用">
<link href="/static/css2/main.css" rel="stylesheet" type="text/css">
<link href="/static/css2/qq.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js2/jquery_002.js"></script>
<style type="text/css">
.xbox{width:auto;height:auto;padding:15px 20px}
.xbox a { text-decoration:none;}
.xbox a:hover { color:#FF6600; text-decoration:underline;}
.ui-tip{position:relative;zoom:1;}
.xbox h2 { font-size:15px;height:30px; line-height:30px; border-bottom:1px solid #ccc;}
.ui-tip-info {padding-left:20px;zoom:1}
.ui-tip-icon {position:absolute;left:0;top:2px;width:15px;height:22px;display:block;background:url(/img/ui-tip.png) 0px 7px no-repeat;}
.ui-tip-text{display:inline-block;padding-top:3px;padding-bottom:3px;float:left;}
.active-link { text-align:center;padding:20px 0px 10px 0px;}
.ui-black { color:#0099cc;}
.clearf { clear:both;}
#m_top .kd .dmhtel {
    background: url("/static/image2/dmhtel.png") no-repeat scroll 7px center transparent;
    float: left;
    height: 22px;
    padding-left: 25px;
    width: 36px;
}
div, h1, h2, h3, h4, p, form, label, input, img, span{
	margin:0;
	padding:0;
	}
ul{
	margin:0;
	padding:0;
	list-style-type:none;
}
img{border:none;}
a{color:#666; text-decoration:none; }
a:hover{color:#1996E6;}
.cle{clear:both; height:0px; line-height:0px; font-size:0px;}
.chengse{color:#fe5500;}
.lvse{color:#2C9E0A;}
.lanse{color:#1996e6;}
.time{color:#999;}
.yred { color:#FF5500;}
.kd a:hover { text-decoration:underline;}
.kf2gre{color: #438FC9;}
a.kf2gre {color: #3372A2;}
a.kf2c { color:#999999;}
#m_top{
	width:100%;
	background:#EFF6FE;
	border-bottom:1px solid #DBEBFA;
	height:25px;
	line-height:25px;
	}
#m_top .hy a {
    color: #1595DE;
    margin: 0 10px;
}
#m_top .hy a.col3 {
    color: #666;
    margin: 0 10px;
}
#m_top .kd a:hover {
    color: #FE5500;
    text-decoration: underline;
}
#m_top .kd,#m_banner .kd{
	width:980px;
	margin:0 auto;
	}
#m_top .kd { position:relative;}
.kmain { width:898px; position:absolute; top:0px; }
.menu_qq {text-align:right;}
#m_top .hy{float:left;}
#m_top .hy a{margin:0 5px;}
#m_top .top_btn{
	float:right;
	color:#1595DE
	}
#m_top .top_btn a{margin:0 10px;color:#1595DE;}
#m_logo{
	margin:0 auto;
	width:1000px;
	height:102px;
	}
#m_logo .kd .hy a.dmhtel {
	width:36px;
	height:22px;
	background:url(/static/image2/dmhtel.png no-repeat);
	float:left;
	padding-left:18px;
}
#m_logo .logo{
	float:left;
	display:block;
	width:250px;
	height:40px;
	margin:32px 0 0 10px;
	}
#m_logo .gg{
	float:right;
	border:1px solid #ddd;
	margin-top:15px;
	}
#m_menu{
	background:url(/static/image2/d_img.jpg) 0 -2015px repeat-x;
	height:39px;
	width:100%;
	}
.menu_qq a {
    font-family:Tahoma,​Helvetica,​Arial,​宋体;
	padding-left:26px;
	font-size:12px;
	color:#1595DE;
}
#m_menu .menu_nav{
	width:1000px;
	margin:0 auto;
	}

.menu_qq .qq_help {
	background: url(/static/image2/tx_ico.gif) no-repeat scroll 0 -958px transparent;
}
#m_menu .m_menu_nav { width:1000px;}
#m_menu .m_menu_nav li{float:left;}
#m_menu .m_menu_nav li a{
	display:block;
	height:39px;
	line-height:35px;
	width:90px;
	font-size:14px;
	font-weight:bold;
	margin:0 5px;
	text-align:center;
	}
#m_menu .m_menu_nav li a:hover,#m_menu .m_menu_nav li a.current{
	background:url(/static/image2/d_img.jpg) 0 -2068px no-repeat;
	color:#fff;
	text-decoration:none;
	}
#footer{
	background:url(/static/image2/ico.jpg) 0 -1102px repeat-x;
	height:83px;
	width:100%;
	margin:15px auto 0;
	text-align:center;
	padding-top:12px;
	}
#footer p .chengse{
	background:url(/static/image2/ico.jpg) 0 -543px no-repeat;
	padding-left:26px;
	}
#footer p.lanse a{
	margin:0 8px;
	color:#1996e6;
	}
.help_down {
    background:#FFFFFF;
    border: 3px solid #7FC3F4;
    padding: 0px 10px;
    position: absolute;
    right: 0;
    top: 25px;
    width: 510px;
	z-index:9999;
}
.help_down .up {
    border-bottom: 1px dashed #DDDDDD;
    font-size: 12px;
    font-weight: bolder;
    height: 30px;
	color:#F50;
    line-height: 30px;
    padding-left: 10px;
}
.help_down .up span {
    font-size: 12px;
}
.help_down ul {
    padding-left: 10px;
    padding-top: 6px;
}
.help_down ul li {
    background: none repeat scroll 0 0 transparent;
    height: 30px;
    line-height: 30px;
    width: 483px;
}
.help_down ul li span {
    float: left;
    font-weight: bolder;
    height: 30px;
    width: 80px;
}
.help_down ul li div {
    float: left;
    text-align: left;
    width: 395px;
}
.help_down ul li img {
    margin-bottom: -3px;
    margin-right: 3px;
}
.help_down ul li a {
    font-weight: normal;
    margin-right: 5px;
}
.help_down ul li .aa {
    color: #999999;
}
.help_down ul li .aa:hover {
    color: #FF5500;
    text-decoration: none;
}
.help_down .down {
    border-top: 1px dashed #DDDDDD;
    font-weight: bolder;
    height: 28px;
    line-height: 28px;
    padding-left: 10px;
}
.help_down .down span {
    color: #666666;
    font-weight: normal;
    margin-left: 10px;
}
.help_down .down b {
    color: #FF5500;
    margin-left: 10px;
}
*{padding:0;margin:0}
body{
	background:#fff;
	padding:0;
	margin:0;
	font:12px/23px "微软雅黑","雅黑",verdana,arial,"宋体";
	width:100%;
	color:#666;
	}
div, h1, h2, h3, h4, p, form, label, input, img, span{
	margin:0;
	padding:0;
	}
ul{
	margin:0;
	padding:0;
	list-style-type:none;
}
a{color:#666; text-decoration:none; }
a:hover{text-decoration:underline;}
.yanse{color:#f90;font-size:14px;font-weight:bold;}
.yanse2{color:#1996e6;font-weight:bold;}
.STYLE1 {color: #FF0000}
.STYLE3 {color: #FF0000; font-weight: bold; }
.STYLE4 {color: #151515}
.STYLE5 {color: #FF0000; font-weight: bold; font-size: 13px; }
.STYLE7 {color: #FF0000; font-size: 13px; }
.hongse{color:#eb0f0f;}
#gm_kd{
	width:900px;
	margin:20px auto;
	}
#gm_kd .line{
	float:left;
	margin:30px 10px 20px;
	_margin:30px 7px 20px;
	background:url(/static/image2/dg_img.gif) -18px -24px no-repeat;
	width:430px;
	height:198px;
	position:relative;
	}
#gm_kd .bg2{
	background:url(/static/image2/dg_img.gif) -461px -24px no-repeat;
	}
#gm_kd .line p{
	position:absolute;
	line-height:30px;
	height:30px;
	top:135px;
	left:33px;
	}
#gm_kd .line .t2{
	position:absolute;
	top:135px;
	left:180px;
	}
#gm_kd .line .in_bk{
	height:28px;
	line-height:22px;
	width:75px;
	border:1px solid #e4e4e4;
	position:absolute;
	top:135px;
	left:92px;
	color:#FF0000;
	font-size:18px;
	font-family:Georgia, "Times New Roman", Times, serif;
	padding-left:7px;
	font-weight:bold;
	}
#gm_kd .line .gm_btn{
	background:url(/static/image2/dg_btn.png) 0 0 no-repeat;
	width:120px;
	height:37px;
	line-height:99px;
	display:block;
	position:absolute;
	top:132px;
	left:287px;
	display:block;
	overflow:hidden;
	text-indent:999px;
	border:none;
	cursor:pointer;
	}
#gm_kd .line .gm_btn:hover{
	background:url(/static/image2/dg_btn.png) 0 -37px no-repeat;
	}
#gm_kd .line select{margin-right:10px;}
#gm_kd .line .jiage{
	position:absolute;
	top:89px;
	left:157px;
	color:#f90;
	font-size:14px;
	font-weight:bold;
	}
#gm_kd .line .jiage .tq{
	margin-left:10px;
	color:#1996e6;
	font-size:12px;
	}
#list{
	margin:20px auto;
	}
#list li{
	float:left;
	width:280px;
	height:205px;
	margin:15px 10px;
	_margin:10px 8px;
	}
#list li.k7,#list li.k8,#list li.k9,#list li.k10,#list li.k11{height:100px;width:150px;}
#list li .kp{
	background:url(/static/image2/dg_img.gif) -21px -269px no-repeat;
	height:155px;
	position:relative;
	}
#list li.k2 .kp{background:url(/static/image2/dg_img.gif)  -315px -269px no-repeat;}
#list li.k3 .kp{background:url(/static/image2/dg_img.gif)  -608px -269px no-repeat;}
#list li.k4 .kp{background:url(/static/image2/dg_img.gif)  -21px -464px no-repeat;}
#list li.k5 .kp{background:url(/static/image2/dg_img.gif)  -315px -464px no-repeat;}
#list li.k6 .kp{background:url(/static/image2/dg_img.gif)  -608px -464px no-repeat;}
#list li.k7 .kp{background:url(/static/image2/dg_img.gif)  -21px -652px no-repeat;height:55px;width:135px;}
#list li.k8 .kp{background:url(/static/image2/dg_img.gif)  -176px -652px no-repeat;height:55px;width:135px;}
#list li.k9 .kp{background:url(/static/image2/dg_img.gif)  -330px -652px no-repeat;height:55px;width:135px;}
#list li.k10 .kp{background:url(/static/image2/dg_img.gif)  -480px -652px no-repeat;height:55px;width:135px;}
#list li.k11 .kp{background:url(/static/image2/dg_img.gif)  -633px -652px no-repeat;height:55px;width:135px;}
#list li .kp .btn2{
	background:url(/static/image2/dg_btn.png) 0 -82px no-repeat;
	display:block;
	height:29px;
	width:78px;
	position:absolute;
	top:109px;
	left:184px;
	display:block;
	line-height:99px;
	text-indent:99px;
	border:none;
	cursor:pointer;
	overflow:hidden;
	}
#list li.k7 .btn2,#list li.k8 .btn2{
	background:url(/static/image2/dg_btn.png) 0 -82px no-repeat;
	display:block;
	height:29px;
	width:78px;
	line-height:99px;
	text-indent:99px;
	border:none;
	cursor:pointer;
	overflow:hidden;
	}
#list li .kp .btn2:hover,#list li.k7 .btn2:hover,#list li.k8 .btn2:hover{background:url(/static/image2/dg_btn.png) 0 -112px no-repeat;}
#list li .text{
	padding:10px 0 0 10px;
	color:#434343;
	font-size:14px;
	}
#list li .text .js{
	color:#707070;
	font-weight:normal;
	}
.comm_fram {position:absolute; left:50%;top:50%; width:600px;*_margin-top:300px; font-size:12px; z-index:1002;overflow: hidden;width: 413px}
.comm_fram_top{ background:url(/static/image2/shadow_bg_02.png);height: 5px; overflow: hidden;width: 413px;}
.fram_container {background: url(/static/image2/r_center.png) repeat-y left top #FFFFFF;overflow: hidden; padding: 0 5px;width: 403px; color:#333;}
.r_title {background:#F1F7FC; font-size: 14px; height: 30px;line-height: 30px; position: relative; text-indent: 9px; width: 403px;}
a.r_close {background-image: url(/static/image2/bg_05.png);height: 17px;position: absolute;width: 17px;}
a.r_close:hover {background-image: url(/static/image2/bg_11.png);}
.comm_fram .fram_container .r_title a.r_close, a.r_close:hover {
    right: 7px;
    top: 6px;
}
.comm_fram .input {padding: 2px; width:250px; color:#ccc;}
.comm_fram_bottom{ background:url(/static/image2/shadow_bg_02.png); background-position:0px -7px;height: 5px; overflow: hidden;width: 413px;}
.rvxsjh { height:250px; padding:0 10px; position:relative;}
.comm_fram .btn{text-align:right;background:#f9f9f9;position:absolute; height:32px;bottom:20px; right:10px;}
.btn_em,.btn_em:hover,.btn_dft,.btn_dft:hover{width:69px;height:32px;margin-right:10px;font-size:14px;font-weight:bold;cursor:pointer;border:none;color:#464646;background:url(/static/image2/verification_button.png) no-repeat;}
.btn_dft{background-position:0 0;}
.btn_dft:hover{background-position:0 -32px;}
.btn_em{background-position:0 -70px;}
.btn_em:hover{background-position:0 -102px;}
.btn .note{position:absolute;left:10px;top:5px;line-height:24px;text-align:left;}

</style>
</head>
<body>
<script src="/ServiceQQ.htm"></script><div style="top: 121px; left: auto; right: 82.5px; position: fixed;" class="service">		<div class="info" style="display: none;">			<div class="i-h">				<span class="s-h1">联系我们</span>				<div class="s-h-ico"><i class="ico circle-qq"></i><i class="ico circle-phone"></i></div>			</div>			<div class="i-1 s-title">网商业务咨询</div>			<div class="i-2"><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes">客服小麦</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes"><img src="/pa_003.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes">客服小黄</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes"><img src="/pa_004.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes">客服小芸</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes"><img src="/pa.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes">客服小粉</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes"><img src="/pa_002.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label>				<span class="s-title">网商互动QQ群</span>			</div>			<div class="i-3">				<label class="qq-indent">					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7">140904771</a>					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7"><img src="/group.png" alt="大麦户刷钻平台26群" title="大麦户刷钻平台26群" border="0"></a>				</label>			</div>		</div>		<div class="box">			<div class="s-h">				<div class="ico qq"></div>				<div class="t">					<i class="ico left-arrow"></i>					<i class="ico stext"></i>				</div>			</div>			<div class="s-f"><a href="#">返回顶部</a><i class="ico top-arrow"></i></div>		</div>	</div>
<!--头部开始-->
	<style>
#dmh_head {background: #EFF6FE;border-bottom: 1px solid #DBEBFA;height: 25px;left: 0;position: fixed;width: 100%;z-index: 9999;}
#dmh_head .kd {position: relative;}
#dmh_head .kd, #m_banner .kd {margin: 0 auto;width: 980px;}
#dmh_head .kmain {position: absolute;top: 0;width: 898px;}
#dmh_head .hy {float: left;}
#dmh_head .kd .dmhtel {background: url("/static/image2/dmhtel.png") no-repeat scroll 7px center transparent;float: left;height: 22px;padding-left: 25px;width: 36px;}
#dmh_head .hy a {color: #1595DE;margin: 0 5px;}
#dmh_head .hy a.col3 {color: #666666;margin: 0 10px;}
#dmh_head .top_btn {color: #1595DE;float: right;}
#dmh_head .top_btn a {color: #1595DE;margin: 0 10px;}
#dmh_head .menu_qq {text-align: right;}
#dmh_head .menu_qq a {color: #1595DE;font-family: Tahoma,​Helvetica,​Arial,​宋体;font-size: 12px;padding-left: 26px;}
#dmh_head .menu_qq .qq_help {background: url("/static/image2/tx_ico.gif") no-repeat scroll 0 -958px transparent;}
#dmh_head .help_down {background: none repeat scroll 0 0 #FFFFFF;border: 3px solid #7FC3F4;padding: 0 10px;position: absolute;right: 0;top: 25px;width: 500px;z-index: 9999;height:255px;*height:270px;}
#dmh_head .help_down ul {border-bottom: 1px dashed #DDDDDD;padding-left: 10px;padding-top: 6px;}
#dmh_head a:hover{color:#FE5500}
#dmh_head b{color:#FE5500}
#dmh_head .quick-menu {margin: 2px 0 0 0;}
#dmh_head .quick-menu li.menu-item {padding: 1px 0 0;position: relative;margin-right: 1px;}
#dmh_head .quick-menu li {background-position: right 6px;float: left;margin-left: -1px;background:none;border:1px solid #EFF6FE;}
#menu-0{display:none;}
#dmh_head .menu {position: relative;float: left;line-height: 140%;}
#dmh_head .menu-hd {cursor: pointer;height: 20px;padding: 1px 22px 0 16px;position: relative;z-index: 10002;}
#dmh_head .menu-hd b {border-color: #666666 #EFF6FE #EFF6FE;border-style: solid;border-width: 4px;font-size: 0;height: 0;line-height: 0;position: absolute;right: 10px;top: 6px;transition: transform 0.2s ease-in 0s;width: 0;}
/*针对客服帮助*/
#dmh_head .help_down {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 3px solid #7FC3F4;
    height:195px;
    padding: 0 10px;
    position: absolute;
    right: 0;
    top: 25px;
    width: 500px;
    z-index: 9999;
}
</style>
<div id="dmh_head">
	<div class="kd">
	    <div class="kmain">
			<div class="hy">


				<div style="float:left;">

					<span style="color:#666">亲，欢迎来到{webName}！请</span>
					<a href="http://www.idc-hosting.com/user/login/" class="chengse">登录</a>
					<a href="http://www.idc-hosting.com/user/reg/" class="lvse">免费注册</a>
				</div>

			</div>
			<div class="top_btn">

				<ul class="quick-menu">
					<a href="http://www.idc-hosting.com/user/reg/" style="float:left;margin-top: -1px;"><b>新手帮助</b></a>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/html/express/" style="width:50px;margin:0;" class="menu-hd" tabindex="0">帮助中心<b></b></a>
							<div style="width: 105px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/diagram/index/">图文实录教程</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskout/">我是发布方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskin/">我是接手方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/bilking/">防骗小课堂</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/help/selfservice/" style="width:52px;margin:0;" class="menu-hd" tabindex="0">账号设置<b></b></a>
							<div style="width: 90px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回密码</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回操作码</a>
								   <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/">更多操作</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<a href="http://www.idc-hosting.com/rank.html" style="margin-top: -2px;">排行榜</a>
				</ul>

			</div>
		</div>

		<div class="menu_qq">
			<a class="qq_help" onmouseover="showcsqq();" href="javascript:;">客服帮助</a>
		</div>
		<div id="service_qq" class="help_down" style="display:none;"></div>
	</div>
</div>
<script>
$(function(){
	$(".menu-item .menu-hd").hover(function(){
		$(this).next('#menu-0').show();
		$(this).children('b').css({borderColor:'#666666 white white',transform:'rotate(180deg',transformOrigin:'50% 30% 0px'});
		$(this).parents(".menu-item").css({background:'rgb(255, 255, 255)',border:'1px solid rgb(191, 191, 191)'})
	});
	$(".menu-item .menu").mouseleave(function(){
		$(this).children('#menu-0').hide();
		$(this).children('.menu-hd').children('b').css({borderColor:'#666666 #EFF6FE #EFF6FE',transform:'none',transformOrigin:'none'});
		$(this).parent(".menu-item").css({background:'none',border:'1px solid #EFF6FE'})
	});
})
</script>

	<!--logo开始-->
	<div id="m_logo">
		<a href="http://www.idc-hosting.com/" class="logo"><img src="/static/image2/head_logo.png" alt="大麦户_淘宝刷信誉"></a>
		<a href="http://www.idc-hosting.com/fuwu/video/" class="gg" target="_blank"><img src="/static/image2/ddd.gif" alt="视频教程" title="视频教程" border="0" height="67" width="689"></a>
	</div>
	<!--菜单开始-->
<div id="m_menu" style="position:relative;">
	<div class="menu_nav">
		<div class="m_menu_nav">
			<ul>
			<?php include"menu.php";?>
			</ul>
		</div>
	</div>
</div>

<!-- page head end and content st-->

                  <div class="cle"></div>
       <div id="content" style="background:#ececec;width:1000px; margin:0 auto;">
		<div id="gm_kd">
		    <form name="myForm" method="post" id="myForm" action="" onsubmit="return checkForm();">
			<div class="line">
			    <p style="height: 30px;left: 140px;line-height: 30px; position: absolute;top: 100px; font-weight:bold;"><a href="#">&nbsp;</a></p>
				<p class="STYLE5">购买数量：</p><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input name="jiage" id="jiage" value="0.68" type="hidden">
				<input name="nums" id="nums" class="in_bk" maxlength="4" value="20" type="text">
				<p class="t2"><span class="STYLE3">个</span><span class="STYLE4">(每个<strong id="jiage1">0.68</strong>元)</span></p>
				<input name="submit" class="gm_btn" type="submit">
			</div>
			</form>
			<form name="myForm1" method="post" id="myForm1" action="/user/vip/?type=add" onsubmit="return confirm('你确定购买VIP，立即享受18重平台特权吗？');">
			<div class="line bg2">
				<p>
				<input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden">
				<select name="viptype" id="viptype">
				  <option selected="selected" value="1">一级VIP客户</option>
				  <option value="2">钻石VIP客户</option>
				  <option value="3">皇冠VIP客户</option>
				</select>
				<select name="months" id="months"><option selected="selected" value="1">一个月29元</option><option value="2">二个月56元</option><option value="3">三个月75元</option><option value="6">半年138元</option><option value="12">一年239元</option><option value="24">二年429元</option></select>
				</p>
				<div class="jiage"><span class="STYLE7">价格：<span id="price">29</span>元</span><a href="http://www.idc-hosting.com/vip.html" class="tq" target="_blank">查看VIP特权</a></div>
				<input name="submit" class="gm_btn" type="submit">
			</div>
			</form>
			<ul id="list">
				<li class="k1">
					<div class="kp" onclick=""><form action="" method="post" onsubmit="return false;" name="forma" id="forma"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="a" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">为您增加<span class="hongse"><strong>260</strong></span>个麦点，尽情发布任务去吧</p>
				</li>
				<li class="k2">
					<div class="kp"><form action="" method="post" onsubmit="return false;" name="formb" id="formb"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="b" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">卡内含<span class="hongse"><strong>501</strong></span>个麦点，发布任务也如此激情</p>
				</li>
				<li class="k3">
					<div class="kp"><form action="" method="post" onsubmit="return false;" name="formc" id="formc"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="c" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">卡内含<span class="hongse"><strong>1001</strong></span>个麦点，畅快淋漓尊享三钻</p>
				</li>
				<li class="k4">
					<div class="kp"><form action="" method="post" onsubmit="return false;" name="formd" id="formd"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="d" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">内含<span class="hongse"><strong>2001</strong></span>个麦点，四钻到手莫着急</p>
				</li>
				<li class="k5">
					<div class="kp"><form action="" method="post" onsubmit="return false;" name="forme" id="forme"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="e" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">内含<span class="hongse"><strong>5001</strong></span>个麦点，五钻是幸福的</p>
				</li>
				<li class="k6">
					<div class="kp"><form action="" method="post" onsubmit="return false;" name="formf" id="formf"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="f" type="hidden"><input class="btn2" type="submit"></form></div>
					<p class="text">内含<span class="hongse"><strong>10001</strong></span>个麦点，<span class="STYLE1">至尊信誉，皇冠在手</span></p>
				</li>
				<li class="k7">
					<div class="kp" id="formj" style="cursor:pointer;"></div>
					<p class="text">价格：<span class="hongse">3元/张</span></p>
					<form action="/user/buycards/" method="post" name="formj"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="j" type="hidden"></form>
				</li>
				<li class="k8">
					<div class="kp" id="formk" style="cursor:pointer;"></div>
					<p class="text">价格：<span class="hongse">16元/张</span></p>
					<form action="/user/buycards/" method="post" name="formk"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="k" type="hidden"></form>
				</li>
				<li class="k9">
					<div class="kp" id="autotk" style="cursor:pointer;"></div>
					<p class="text">价格：<span class="hongse">1元/天</span></p>
				</li>
				<li class="k10">
					<div class="kp" id="removegrade" style="cursor:pointer;"></div>
					<p class="text">价格：<span class="hongse">5元/张</span></p>
					<form action="/user/buycards/" method="post" name="formm"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="m" type="hidden"></form>
				</li>
				<li class="k11">
					<div class="kp" id="forml" style="cursor:pointer;"></div>
					<p class="text">价格：<span class="hongse">5元/张</span></p>
					<form action="/user/buycards/" method="post" name="forml"><input name="hash2" value="Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==" type="hidden"><input value="add" name="type" type="hidden"><input name="card" value="l" type="hidden"></form>
				</li>
			</ul>
			<div style="clear:both"></div>
		</div>

	</div>

<div class="cle"></div>
<div id="footer">
  <p><span class="chengse">官方QQ群：<span class="web_qq">147898283</span><span style="display:none;" class="quick_qq"><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img src="/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群" border="0"></a></span></span> （加群请注明大麦户）</p>
		<p class="lanse"><a href="http://www.idc-hosting.com/info/aboutus.html">关于我们</a>|<a href="http://www.idc-hosting.com/info/contactus.html">联系我们</a>|<a href="http://www.idc-hosting.com/info/duty.html">服务条款</a>|<a href="http://www.idc-hosting.com/info/map.html">网站地图</a>|<a href="http://www.yaodamai.com/" target="_blank">淘宝信誉查询</a> </p>
 <!--  <p style="text-align:center;"><a id='___szfw_logo___' href='https://search.szfw.org/cert/l/CX20130730002661002730' target='_blank'><img height='32' src='https://search.szfw.org/cert.png?l=CX20130730002661002730'></a></p> -->
  <p class="lanse">客户服务热线：4006079159   Copyright © 2012-2020 Damaihu.com All RightsReserved    大麦户版权所有 粤ICP备13037934号<span style="display:none;">
</span></p>
</div>
<script type="text/javascript" src="/static/js2/jquery.js"></script>
<script type="text/javascript" src="/static/js2/common.js"></script>
<!--[if lte IE 6]>
<script type="text/javascript" src="/javascript/cn/DD_belatedPNG_0.0.7a.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('*');
</script>
<![endif]-->
<script type="text/javascript">
var webqq = 147898283;
var webnoticeurl = "";
var webnoticetit = "";
var quick_qq = '<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img border="0" src="http://pub.idqqimg.com/wpa/static/image2/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群"></a>';
$(function() {
    getvipjiage(1);
    $('#viptype').change(function(){
    var viptype=$(this).children('option:selected').val();
	getvipjiage(viptype);
	var viprice=$('#months').children('option:selected').val();
    });

	$('#months').change(function(){
    var vipmonths=$(this).children('option:selected').val();
	getviptotal(vipmonths);
    });

});
function getvipjiage(t) {
		if(t){
			$.ajax({
				url: '/ajax/vipprice.php',
				data: 'hash2=Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==&viptype='+t,
				type: "POST",
				cache: false,
				dataType:"json",
				success: function(data){
					if(data!=false){
					    $("#vipbuy").removeAttr("disabled");
						$('#months').html(data.detailed);
						$('#price').html(data.mounth);
					} else {
					    $('#vipbuy').attr({'disabled':'disabled'});
						$('#months').html('读取数据失败');
					}
				}
			});
		}
}
function getviptotal(m) {
        var viptype=$('#viptype').children('option:selected').val();
		if(m){
			$.ajax({
				url: '/ajax/viptotal.php',
				data: 'hash2=Njc4MzRDeXhaOWtYd3RCcE1xb1BaUnNNYnA3TVArWm9DZUZ3bTlDZlNxUGJ0SklFWEZLN1NJK2lRQlVodjhhdlhGK0cwTmk3YlE5SWJsdlE2UQ==&vipmonths='+m+'&viptype='+viptype,
				type: "POST",
				cache: false,
				dataType:"text",
				success: function(data){
					if(data!=false){
					    $("#vipbuy").removeAttr("disabled");
						$('#price').html(data);
					} else {
					    $('#vipbuy').attr({'disabled':'disabled'});
						$('#price').html('参数错误');
					}
				}
			});
		}
}
function checkForm() {
   var n=$("#nums").val();
   var j=$("#jiage").val();
   var checks = [
		["isNumber", "nums", "购买麦点数量"] ];
	var result = doCheck(checks);
	if(n>9999){alert('购买数量不能超过9999');return false;}
	if (result){
	  if(confirm('请确定购买信息' + '\n麦点价格：' + j + '\n麦点数量：' + n + '\n消耗存款：'+ (j*n).toFixed(2)+'元')){
	  return avoidReSubmit();
	  }else{
	  return false;}
	}else{
	  return result;
	}
}
$(document).ready(function(){
    var hash     =$("input[name=hash2]").val();
	$('#forma').submit(function(){
	return kefu_cx('a',hash,'购买一钻卡获得：260个麦点 0.6元/个','156');
    });
	$('#formb').submit(function(){
	return kefu_cx('b',hash,'购买二钻卡获得：501个麦点 0.58元/个','290');
    });
	$('#formc').submit(function(){
	return kefu_cx('c',hash,'购买三钻卡获得：1001个麦点 0.57元/个','570');
    });
	$('#formd').submit(function(){
	return kefu_cx('d',hash,'购买四钻卡获得：2001个麦点 0.56元/个','1080');
    });
	$('#forme').submit(function(){
	return kefu_cx('e',hash,'购买五钻卡获得：5001个麦点 0.55元/个','2600');
    });
	$('#formf').submit(function(){
	return kefu_cx('f',hash,'购买皇冠卡获得：10001个麦点 0.5元/个','5000');
    });
	$('#formj').click(function(){
	  if(confirm('新平台用户积分增长利器，早日成为万人敬仰的平台皇冠达人！\n购买后积分实效为24小时，\n不与会员等级相累计！您确定购买吗？')){

      document.formj.submit();

	  }
    });
	$('#formk').click(function(){
	  if(confirm('新平台用户积分增长利器，早日成为万人敬仰的平台皇冠达人！\n购买后积分实效为7天，\n不与会员等级相累计！您确定购买吗？')){

	   document.formk.submit();
	  }
    });
	$('#forml').click(function(){
	  if(confirm('购买后您的平台有效投诉率将-1，确定购买吗？\n（此卡一月只可以购买一次）\n您确定购买吗？')){

	   document.forml.submit();
	  }
    });
	$('#removegrade').click(function(){
	  if(confirm('此卡仅限一月使用一次，购买后将清理您的一个中评，或者差评，让您的满意度提升！\n您确定购买吗？')){

	   document.formm.submit();
	  }
    });
	$('#autotk').click(function(){
	dialog(615,554,'购买提示','/dialog/autotk/');
    });
});
$('.web_qq').hover(function(){
    $('.quick_qq').show();
});
</script>
<script type="text/javascript">
$('.service').css({
	    'top': $(window).height()-468,
		'left':"auto",
	    'right': ($(window).width() - 1000)>0?($(window).width() - 1000)/2-$('.service').width()-5:0 ,
		'position':"fixed"
	});
</script>
<script type="text/javascript" src="/service.js"></script>


</body></html>