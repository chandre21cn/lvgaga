	<li><a href="http://www.idc-hosting.com/">首页</a></li>
				<li><a href="/home/Dating/taobao">淘宝大厅</a></li>
				<li><a href="/home/Dating/collect/">收藏流量</a></li>
				<li><a href="/home/Dating/Tuoguanfuwu/">网店托管</a></li>
				<li><a href="/home/Dating/DmSEO/" class="current">旺铺推广</a></li>
				<li><a href="/home/user/MemberIndex">会员中心</a></li>
				<li><a href="/home/Dating/buyMaiDian">购买麦点</a></li>
				<li onclick="window.open('/help/guide/')" style="cursor: pointer;margin-left: 5px; background: url(/static/image2/121212.png) no-repeat scroll 0% 0% transparent; width: 95px; height: 49px; margin-top: -13px;"><img src="/static/image2/321.gif" style="margin-top: 20px; margin-left: 3px;"></li>
