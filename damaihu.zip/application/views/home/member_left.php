<!-- left -->
<div class="user_left">
	<!-- 发布任务 -->
	<a href="http://taobao.damaihu.com.cn/#publish/oneTask" class="imgico renwu1"></a>
	<div class="left_alert">
		<ul>
		   <li><a href="http://taobao.damaihu.com.cn/#publish/oneTask">淘宝任务</a></li>
		   <li><a href="http://paipai.damaihu.com.cn/#publish/oneTask">拍拍任务</a></li>
		</ul>
	</div>

	<!-- 线 -->
	<span class="imgdian dian1"></span>
	<span class="imgdian dian2" style="top:260px;height:102px;"></span>
	<span class="imgdian dian3" style="top:422px;"></span>
	<!-- 显示 -->
	<div class="left_main">
		<ul>
			<li>
				<a class="imgico li1 lia_a1"></a>
				<a href="#topup/bank" class="imgico text1 lia_a2"></a>
				<i><img src="/static/images/user/dadian.png" /></i>
			</li>
			<li>
				<a class="imgico li1 lib_a1"></a>
				<a href="#payment/bank" class="imgico text1 lib_a2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lic_a1"></a>
				<a href="#paydetails/payde" class="imgico text1 lic_a2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lid_a1"></a>
				<a href="#rechange" class="imgico text1 lid_a2"></a>
				<i></i>
			</li>
			<li></li>
			<!-- APP下载 -->
			<li>
				<a class="imgico li1 lie_rjxz1"></a>
				<a href="http://www.damaihu.com.cn/Platform/soft" class="imgico text1 lie_rjxz2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lif_a1"></a>
				<a href="#seckill" class="imgico text1 lif_a2"></a>
				<i></i>
			</li>
			<!-- 地雷 -->
			<li>
				<a class="imgico li1 lif_dilei1"></a>
				<a href="http://www.damaihu.com.cn/activity/mineaction" class="imgico text1 lif_dilei2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lig_a1"></a>
				<a href="#black" class="imgico text1 lig_a2"></a>
				<i></i>
			</li>
			<li></li>
			<li>
				<a class="imgico li1 lih_a1"></a>
				<a href="#userData/username" class="imgico text1 lih_a2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lii_a1"></a>
				<a href="http://www.damaihu.com.cn/info/popularize" class="imgico text1 lii_a2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lij_a1"></a>
				<a href="#thread" class="imgico text1 lij_a2"></a>
				<i></i>
			</li>
			<li>
				<a class="imgico li1 lik_a1"></a>
				<a href="http://member.damaihu.com.cn/#message/personal" class="imgico text1 lik_a2"></a>
				<i></i>
			</li>

		</ul>
	</div>
	<a class="imgico renwu2" href="#userjob"></a>
</div>