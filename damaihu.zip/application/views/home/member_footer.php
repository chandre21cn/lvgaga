<div id="footer">
	<p>
		<span class="chengse">官方QQ群：<a style="color:#FE5500;" target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=c67c64edb769392db32cdfb8be110c498dfde9c3fffc7668d56be1cd99cb069">377804205</a></span>
		（加群请注明大麦户）</p>
	<p class="lanse">
		<a href="http://www.damaihu.com.cn/info/about?p=1">联系我们</a>|
		<a href="http://www.damaihu.com.cn/info/about?p=2">大麦户规则</a>|
		<a target="_blank" href="http://www.yaodamai.com/">淘宝信誉查询</a>|
		<a target="_blank" href="http://www.aizhanggui.com/">爱掌柜淘宝培训</a>
	</p><p class="lanse">客户服务热线：4000709880   Copyright © 2012-2020 Damaihu.com All RightsReserved    大麦户版权所有
		<a target="_blank" href="http://www.miitbeian.gov.cn">粤ICP备13037934号</a>
	</p>
</div>
</body>
</html>