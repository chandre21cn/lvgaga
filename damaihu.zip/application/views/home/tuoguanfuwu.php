<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>大麦户信誉托管，让你的信誉蹭蹭蹭_大麦户网商互动平台领跑者，接任务赚佣金，发任务赚信誉，让您生意大卖。</title>
<link rel="shortcut icon" href="http://www.idc-hosting.com/favicon.ico">
<meta name="description" content="刷信誉安全吗?大麦户淘宝刷钻平台不仅给淘宝卖家提供淘宝刷信誉,淘宝刷信用,淘宝刷钻,还提供淘宝刷收藏,刷流量,淘宝托管等增值服务,公司化运营,安全担保,让您的店铺好评如潮.登陆大麦户专业免费淘宝互刷信誉平台!">
<meta name="keywords" content="淘宝刷钻,淘宝刷钻平台,淘宝刷信誉,刷信誉,淘宝刷信用">
<link href="/static/css2/main.css" rel="stylesheet" type="text/css">
<link href="/static/css2/qq.css" rel="stylesheet" type="text/css">
<link href="/static/css2/jcalendar.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js2/jquery.js"></script><script type="text/javascript" src="/static/js2/common.js"></script>
<!--[if lte IE 6]>
<script type="text/javascript" src="/static/js2/javascript/cn/DD_belatedPNG_0.0.7a.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('*');
</script>
<![endif]-->
<script type="text/javascript" src="/static/js2/artDialog.js"></script><style type="text/css">* html body{margin:0}.ui_title_icon,.ui_content,.ui_dialog_icon,.ui_btns span{display:inline-block;*zoom:1;*display:inline}.ui_dialog{text-align:left;display:none;position:absolute;top:0;left:-99999em;_overflow:hidden}.ui_dialog table{border:0;margin:0;border-collapse:collapse}.ui_dialog td{padding:0}.ui_title_icon{vertical-align:middle}.ui_title_text{overflow:hidden;cursor:default;-moz-user-select:none;user-select:none}.ui_close{display:block;position:absolute;outline:none}.ui_content_wrap{height:auto;text-align:center}.ui_content{margin:10px;text-align:left}.ui_dialog_icon{vertical-align:middle}.ui_content.ui_iframe{margin:0;*padding:0;display:block;height:100%}.ui_iframe iframe{width:100%;height:100%;border:none;overflow:auto}.ui_bottom{position:relative}.ui_resize{position:absolute;right:0;bottom:0;z-index:1;cursor:nw-resize;_font-size:0}.ui_btns{text-align:right;white-space:nowrap}.ui_btns span{margin:5px 10px}.ui_content em{font-weight:700;font-style:normal;color:#ff5500;}.ui_btns button{cursor:pointer}.ui_overlay{display:none;position:absolute;top:0;left:0;width:100%;height:100%;filter:alpha(opacity=0);opacity:0;_overflow:hidden}.ui_overlay div{height:100%}* html .ui_ie6_select_mask{width:99999em;height:99999em;position:absolute;top:0;left:0;z-index:-1}.ui_move .ui_title_text{cursor:move}html >body .ui_dialog_wrap.ui_fixed .ui_dialog{position:fixed}* html .ui_dialog_wrap.ui_fixed .ui_dialog{fixed:true}* html.ui_ie6_fixed{background:url(*) fixed}* html.ui_ie6_fixed body{height:100%}* html .ui_dialog_wrap.ui_fixed{width:100%;height:100%;position:absolute;left:expression(documentElement.scrollLeft+documentElement.clientWidth-this.offsetWidth);top:expression(documentElement.scrollTop+documentElement.clientHeight-this.offsetHeight)}html.ui_page_lock >body{overflow:hidden}* html.ui_page_lock{overflow:hidden}* html.ui_page_lock select,* html.ui_page_lock .ui_ie6_select_mask{visibility:hidden}html.ui_page_lock >body .ui_dialog_wrap.ui_lock{width:100%;height:100%;position:fixed;top:0;left:0}</style>
<script type="text/javascript" src="/static/js2/Common.js"></script>
<script type="text/javascript">
var webqq = 147898283;
var webnoticeurl = "";
var webnoticetit = "";

</script>
<script type="text/javascript" src="/static/js2/jcalendar.js"></script>
<style type="text/css">
.kd a:hover { text-decoration:underline;}
.ds_tit { float:left; width:125px;}
.ds_qq { float:left; height:46px; line-height:46px;}
.Discount { width:600px; height:70px;margin-top:10px;margin-left:2px;font-family:Microsoft YaHei,微软雅黑;font-size:25px;text-indent:105px;line-height:45px;color:#fb7819;background:url(/static/images/hdsj.jpg) no-repeat;}
</style>
</head>

<body>
<script src="/ServiceQQ.htm"></script><div style="top: 94px; left: auto; right: 82.5px; position: fixed;" class="service">		<div class="info" style="display: none;">			<div class="i-h">				<span class="s-h1">联系我们</span>				<div class="s-h-ico"><i class="ico circle-qq"></i><i class="ico circle-phone"></i></div>			</div>			<div class="i-1 s-title">网商业务咨询</div>			<div class="i-2"><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes">客服小芸</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=2354858040&amp;site=qq&amp;menu=yes"><img src="/pa.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes">客服小黄</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239033&amp;site=qq&amp;menu=yes"><img src="/pa_008.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes">客服小粉</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239031&amp;site=qq&amp;menu=yes"><img src="/pa_004.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label><label>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes">客服小麦</a>			<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=188239032&amp;site=qq&amp;menu=yes"><img src="/pa_006.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0"></a>		</label>				<span class="s-title">网商互动QQ群</span>			</div>			<div class="i-3">				<label class="qq-indent">					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7">140904771</a>					<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=2349adbc9af3cded003121d88ae2d47e1a4fafd114ae8fd8a8499a44abd45af7"><img src="/group.png" alt="大麦户刷钻平台26群" title="大麦户刷钻平台26群" border="0"></a>				</label>			</div>		</div>		<div class="box">			<div class="s-h">				<div class="ico qq"></div>				<div class="t">					<i class="ico left-arrow"></i>					<i class="ico stext"></i>				</div>			</div>			<div class="s-f"><a href="#">返回顶部</a><i class="ico top-arrow"></i></div>		</div>	</div>
	<!--头部开始-->
	<style>
#dmh_head {background: #EFF6FE;border-bottom: 1px solid #DBEBFA;height: 25px;left: 0;position: fixed;width: 100%;z-index: 9999;}
#dmh_head .kd {position: relative;}
#dmh_head .kd, #m_banner .kd {margin: 0 auto;width: 980px;}
#dmh_head .kmain {position: absolute;top: 0;width: 898px;}
#dmh_head .hy {float: left;}
#dmh_head .kd .dmhtel {background: url("/static/images/dmhtel.png") no-repeat scroll 7px center transparent;float: left;height: 22px;padding-left: 25px;width: 36px;}
#dmh_head .hy a {color: #1595DE;margin: 0 5px;}
#dmh_head .hy a.col3 {color: #666666;margin: 0 10px;}
#dmh_head .top_btn {color: #1595DE;float: right;}
#dmh_head .top_btn a {color: #1595DE;margin: 0 10px;}
#dmh_head .menu_qq {text-align: right;}
#dmh_head .menu_qq a {color: #1595DE;font-family: Tahoma,​Helvetica,​Arial,​宋体;font-size: 12px;padding-left: 26px;}
#dmh_head .menu_qq .qq_help {background: url("/static/images/tx_ico.gif") no-repeat scroll 0 -958px transparent;}
#dmh_head .help_down {background: none repeat scroll 0 0 #FFFFFF;border: 3px solid #7FC3F4;padding: 0 10px;position: absolute;right: 0;top: 25px;width: 500px;z-index: 9999;height:255px;*height:270px;}
#dmh_head .help_down ul {border-bottom: 1px dashed #DDDDDD;padding-left: 10px;padding-top: 6px;}
#dmh_head a:hover{color:#FE5500}
#dmh_head b{color:#FE5500}
#dmh_head .quick-menu {margin: 2px 0 0 0;}
#dmh_head .quick-menu li.menu-item {padding: 1px 0 0;position: relative;margin-right: 1px;}
#dmh_head .quick-menu li {background-position: right 6px;float: left;margin-left: -1px;background:none;border:1px solid #EFF6FE;}
#menu-0{display:none;}
#dmh_head .menu {position: relative;float: left;line-height: 140%;}
#dmh_head .menu-hd {cursor: pointer;height: 20px;padding: 1px 22px 0 16px;position: relative;z-index: 10002;}
#dmh_head .menu-hd b {border-color: #666666 #EFF6FE #EFF6FE;border-style: solid;border-width: 4px;font-size: 0;height: 0;line-height: 0;position: absolute;right: 10px;top: 6px;transition: transform 0.2s ease-in 0s;width: 0;}
/*针对客服帮助*/
#dmh_head .help_down {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 3px solid #7FC3F4;
    height:195px;
    padding: 0 10px;
    position: absolute;
    right: 0;
    top: 25px;
    width: 500px;
    z-index: 9999;
}
</style>
<div id="dmh_head">
	<div class="kd">
	    <div class="kmain">
			<div class="hy">


				<div style="float:left;">

					<span style="color:#666">亲，欢迎来到{webName}！请</span>
					<a href="http://www.idc-hosting.com/user/login/" class="chengse">登录</a>
					<a href="http://www.idc-hosting.com/user/reg/" class="lvse">免费注册</a>
				</div>

			</div>
			<div class="top_btn">

				<ul class="quick-menu">
					<a href="http://www.idc-hosting.com/user/reg/" style="float:left;margin-top: -1px;"><b>新手帮助</b></a>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/html/express/" style="width:50px;margin:0;" class="menu-hd" tabindex="0">帮助中心<b></b></a>
							<div style="width: 105px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/diagram/index/">图文实录教程</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskout/">我是发布方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskin/">我是接手方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/bilking/">防骗小课堂</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/help/selfservice/" style="width:52px;margin:0;" class="menu-hd" tabindex="0">账号设置<b></b></a>
							<div style="width: 90px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回密码</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回操作码</a>
								   <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/">更多操作</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<a href="http://www.idc-hosting.com/rank.html" style="margin-top: -2px;">排行榜</a>
				</ul>

			</div>
		</div>

		<div class="menu_qq">
			<a class="qq_help" onmouseover="showcsqq();" href="javascript:;">客服帮助</a>
		</div>
		<div id="service_qq" class="help_down" style="display:none;"></div>
	</div>
</div>
<script>
$(function(){
	$(".menu-item .menu-hd").hover(function(){
		$(this).next('#menu-0').show();
		$(this).children('b').css({borderColor:'#666666 white white',transform:'rotate(180deg',transformOrigin:'50% 30% 0px'});
		$(this).parents(".menu-item").css({background:'rgb(255, 255, 255)',border:'1px solid rgb(191, 191, 191)'})
	});
	$(".menu-item .menu").mouseleave(function(){
		$(this).children('#menu-0').hide();
		$(this).children('.menu-hd').children('b').css({borderColor:'#666666 #EFF6FE #EFF6FE',transform:'none',transformOrigin:'none'});
		$(this).parent(".menu-item").css({background:'none',border:'1px solid #EFF6FE'})
	});
})
</script>

	<!--logo开始-->
	<div id="m_logo">
		<a href="http://www.idc-hosting.com/" class="logo"><img src="/static/image2/head_logo.png" alt="大麦户_淘宝刷信誉"></a>
		<a href="http://www.idc-hosting.com/fuwu/video/" class="gg" target="_blank"><img src="/static/image2/ddd.gif" alt="视频教程" title="视频教程" border="0" height="67" width="689"></a>
	</div>
	<!--菜单开始-->
<div id="m_menu" style="position:relative;">
	<div class="menu_nav">
		<div class="m_menu_nav">
			<ul>
			<?php include "menu.php"; ?>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="/static/js2/service.js"></script>
<link rel="stylesheet" type="text/css" href="/static/css2/shua.css">
<script type="text/javascript">
$(function() {
	$("#table tr:odd").css({background:"#e8f9fe"});
});
</script>
	<!--banner 登录框开始-->
	<div id="ds_banner" style="margin-top:0px;">
		<div class="kd">
			<div class="banner">
				<img src="/static/image2/ds_banner.gif" height="302" width="602">
			</div>
			<div class="ds_news">
				<div class="ds_zxlist">
				<table id="table" border="0" cellpadding="0" cellspacing="0" width="95%">

				  <tbody><tr>
					<!--
					<td width="120" height="25">&nbsp; <span>我叫M*</span></td>
					<td>申请<span class="lanse">一钻</span></td>
					<td width="110"><strong class="chengse">250</strong>个信誉</td>
					-->
					<td height="25" width="120">&nbsp; <span>我叫M*</span></td>
					<td>申请托管</td>
					<td width="110"><strong class="chengse">250</strong>笔交易</td>
				  </tr>

				  <tr style="background: none repeat scroll 0% 0% rgb(232, 249, 254);">
					<!--
					<td width="120" height="25">&nbsp; <span>我叫M*</span></td>
					<td>申请<span class="lanse">二钻</span></td>
					<td width="110"><strong class="chengse">500</strong>个信誉</td>
					-->
					<td height="25" width="120">&nbsp; <span>我叫M*</span></td>
					<td>申请托管</td>
					<td width="110"><strong class="chengse">500</strong>笔交易</td>
				  </tr>

				  <tr>
					<!--
					<td width="120" height="25">&nbsp; <span>我叫M*</span></td>
					<td>申请<span class="lanse">一钻</span></td>
					<td width="110"><strong class="chengse">250</strong>个信誉</td>
					-->
					<td height="25" width="120">&nbsp; <span>我叫M*</span></td>
					<td>申请托管</td>
					<td width="110"><strong class="chengse">250</strong>笔交易</td>
				  </tr>

				  <tr style="background: none repeat scroll 0% 0% rgb(232, 249, 254);">
					<!--
					<td width="120" height="25">&nbsp; <span>zha*****</span></td>
					<td>申请<span class="lanse">四钻</span></td>
					<td width="110"><strong class="chengse">2000</strong>个信誉</td>
					-->
					<td height="25" width="120">&nbsp; <span>zha*****</span></td>
					<td>申请托管</td>
					<td width="110"><strong class="chengse">2000</strong>笔交易</td>
				  </tr>

				  <tr>
					<!--
					<td width="120" height="25">&nbsp; <span>zha*****</span></td>
					<td>申请<span class="lanse">一钻</span></td>
					<td width="110"><strong class="chengse">250</strong>个信誉</td>
					-->
					<td height="25" width="120">&nbsp; <span>zha*****</span></td>
					<td>申请托管</td>
					<td width="110"><strong class="chengse">250</strong>笔交易</td>
				  </tr>

				</tbody></table>
				</div>
				<p class="ds_wc">已完成：<strong class="chengse">5000</strong> 笔交易</p>
				<div class="ds_btn">
				<a href="javascript:;"
				<?php if(!isset($_SESSION['member'])):?>
				onclick="alert('亲，您需要先登陆哦！');location.href='/home/user/login/';"
				<?php else:?>
				onclick="javascript:if(confirm('订购托管后，将有客服与您取得联系，请保持QQ，手机通信正常。确定订购吗？'))document.getElementById('myForm6').submit();"
				<?php endif;?>
				class="btn">
				</a><a href="javascript:;"
				<?php if(!isset($_SESSION['member'])):?>
				onclick="alert('亲，您需要先登陆哦！');location.href='/home/user/login/';"
				<?php else:?>
				onclick="javascript:if(confirm('订购托管后，将有客服与您取得联系，请保持QQ，手机通信正常。确定订购吗？'))document.getElementById('myForm6').submit();"
				<?php endif;?>
				class="btn2"></a></div>
			</div>
		</div>
	</div>
	<div id="content">
		<div class="ds_about">
		  <table border="0" cellpadding="0" cellspacing="0" height="115" width="1000">
              <tbody><tr>
                <td class="ds_a1" width="20">&nbsp;</td>
                <td class="ds_a2" width="290"><span class="ds_fw"></span><p>我们的服务</p>
                专业的团队，多年的经验！<br>一直致力于淘宝网店服务研究！</td>
                <td class="ds_a2"><span class="ds_fw2"></span><p>我们的承诺</p>降多少补多少，封了再帮您刷一个店！<br>把店交给我们，将不辜负您的重托！</td>
                <td class="ds_a2"><span class="ds_fw3"></span><p>我们的优势</p>价格低廉，时间短，效率高！<br>让您用最少的付出获得最大的回报！</td>
                <td class="ds_a3" width="10">&nbsp;</td>
              </tr>
          </tbody></table>
		</div>
		<p class="Discount" style="display:none">优惠活动剩余时间：<span id="sale_times">0</span>秒</p>
		<div class="ds_cplist">
			<h4 class="ds_tit">收费标准</h4><h5 class="ds_qq"><a class="kf2gre" href="tencent://message/?uin=188239031"><img src="/pa_007.gif" border="0"></a><a class="kf2gre" href="tencent://message/?uin=188239031">客服小粉</a>　<a class="kf2gre" href="tencent://message/?uin=188239033"><img src="/pa_005.gif" border="0"></a><a class="kf2gre" href="tencent://message/?uin=188239033">客服小黄</a>　<a class="kf2gre" href="tencent://message/?uin=188239032"><img src="/pa_003.gif" border="0"></a><a class="kf2gre" href="tencent://message/?uin=188239032">客服小麦</a>　<a class="kf2gre" href="tencent://message/?uin=2354858040"><img src="/pa_002.gif" border="0"></a><a class="kf2gre" href="tencent://message/?uin=2354858040">客服小芸</a>　<a href="http://www.idc-hosting.com/Tuoguanfuwu/shuatask/"><img src="/static/image2/heshentuoguan.jpg" align="absmiddle" height="35" width="117"></a></h5>
			<div class="cle"></div>
			<?php
			var_dump($_SESSION['member']);
			foreach($data as $_k=>$items):
				$dataTmp = unserialize($items->eve);
			?>
			<div class="ds_line">
				<p class="name">打理<?php echo $dataTmp['l']?>笔交易</p>
				<span class="ds_dj<?php echo $_k+1;?>"></span>
				<ul class="text">
					<li class="chengse2"><span>价格：<strong><?php echo $dataTmp['m']?></strong>元</span>-<span style="text-decoration: line-through">原价：<strong><?php echo $dataTmp['t']?></strong>元</span></li>
					<li>时间：<strong class="lanse"><?php echo $dataTmp['o']?></strong>天左右</li>
					<li>属性：赠送收藏流量</li>
					<li><a class="ds_btn"
				<?php if(!isset($_SESSION['member'])):?>
				onclick="alert('亲，您需要先登陆哦！');location.href='/home/user/login/';"
				<?php else:?>
				onclick="Gojiao('<?php echo $items->t_id; ?>');"
				<?php endif;?>
					   href="javascript:;"></a></li>
				</ul>
			</div>
			<?php endforeach;?>

		</div>
		<div id="c_bk3" style="height:112px;"><a href="http://www.idc-hosting.com/Tuoguanfuwu/backdoor" target="_blank"><img src="/static/image2/shua_banner.gif"></a></div>
		<div id="c_bk3" style="margin-top:0px;height:344px;">
			<ul class="c_info" style="left:15px;">
				<h4 class="dsym_bt"></h4>
				<li><a href="http://www.idc-hosting.com/bbs/t1331/" target="_blank">大麦户平台托管业务介绍</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1332/" target="_blank">大麦户平台托管业务细则（会员必看，请仔细阅读）</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1330/" target="_blank">为何要托管提升信誉，亲们知道吗？</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1333/" target="_blank">客户托管前的准备</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1334/" target="_blank">需要提供的店铺资料</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1335/" target="_blank">托管提交方法？</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1482/" target="_blank">关于托管物品以及物品金额</a></li>
			</ul>
		</div>
		<div id="c_bk3" style="height:95px;"><img src="/static/image2/shua_banner.jpg"></div>
		<div id="c_bk3" style="height:344px;margin-top:0px;">
			<ul class="c_info" style="left:15px;">
				<h4 class="dsym_bt2"></h4>
				<li><a href="http://www.idc-hosting.com/bbs/t1336/" target="_blank">你托管，或是不托管，托管就在这里</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1342/" target="_blank">怎么开通淘宝E客服帐号？</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1341/" target="_blank">并不是非选我们不可</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1340/" target="_blank">店铺被释放是为什么？</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1339/" target="_blank">托管信誉过程中，支付宝被冻结如何处理！</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1338/" target="_blank">托管注意事项 （重要的）</a></li>
				<li><a href="http://www.idc-hosting.com/bbs/t1337/" target="_blank">谨防托管信誉骗子！</a></li>
			</ul>
		</div>
	</div>
	<div class="cle"></div>
	<script type="text/javascript">
function SaleRefreshTime(t) {
    if (t <0 ) t = 0;
    var id = "#sale_times";
	$(id).html(parseInt(t/3600) + ":" + parseInt((t-(parseInt(t/3600))*3600)/60) + ":" + (t-(parseInt(t/3600))*3600)%60);
    var uptime = function() {
        t = t - 1;
		m = parseInt((t-(parseInt(t/3600))*3600)/60);
		s = (t-(parseInt(t/3600))*3600)%60;
		if(m<10)m='0'+m;
		if(s<10)s='0'+s;
		if (t <= 0) {
		    window.clearInterval(tt_0);
			$("#sale_times").html("0");
            t = 0;
        }
		$(id).html(parseInt(t/3600) + ":" + m + ":" + s);
    }
    var tt_0 = window.setInterval(uptime, 1000);
}

</script>
<script type="text/javascript">
$('.service').css({
	    'top': $(window).height()-508,
		'left':"auto",
	    'right': ($(window).width() - 1000)>0?($(window).width() - 1000)/2-$('.service').width()-5:0 ,
		'position':"fixed"
	});
</script>

<div class="cle"></div>
<div id="footer">
  <p><span class="chengse">官方QQ群：<span class="web_qq">147898283</span><span style="display:none;" class="quick_qq"><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img src="/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群" border="0"></a></span></span> （加群请注明大麦户）</p>
		<p class="lanse"><a href="http://www.idc-hosting.com/info/aboutus.html">关于我们</a>|<a href="http://www.idc-hosting.com/info/contactus.html">联系我们</a>|<a href="http://www.idc-hosting.com/info/duty.html">服务条款</a>|<a href="http://www.idc-hosting.com/info/map.html">网站地图</a></p>
  <p class="lanse">客户服务热线：4006079159   Copyright © 2012-2020 Damaihu.com All RightsReserved    大麦户版权所有 <a href="http://www.miitbeian.gov.cn/" target="_blank">粤ICP备13037934号</a>
</p>
</div>
<script type="text/javascript">

function Gojiao(i)
{
	alert(i);
	$.ajax({
			url:'/home/User/CutMoney/',
			type:'post',
			data:{t_id:i},
			dataType:'json',
			success:function(data){
					switch(data.msg){
					case 'nomoney':alert('余额不足');
					break;
					case 'ok':alert('成功');
					break;
					case 'nologin':alert('请重新登录');
					break;
					}
				}

		});
}
var webnoticeurl = "";
var webnoticetit = "";
var quick_qq = '<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img border="0" src="http://pub.idqqimg.com/wpa/static/images/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群"></a>';
$('.web_qq').hover(function(){
    $('.quick_qq').show();
});
</script>




<div id="" class="ui_dialog_wrap"><div style="" class="ui_dialog"><table class=""><tbody><tr><td class="ui_border r0d0"></td><td class="ui_border r0d1"></td><td class="ui_border r0d2"></td></tr><tr><td class="ui_border r1d0"></td><td><table class="ui_dialog_main"><tbody><tr><td class="ui_title_wrap"><div class="ui_title"><div class="ui_title_text"></div><a href="javascript:void(0)" class="ui_close">×</a></div></td></tr><tr><td style="width: auto; height: auto;" class="ui_content_wrap"><div id="" class="ui_content "></div></td></tr><tr><td class="ui_bottom_wrap"><div class="ui_bottom"><div class="ui_btns"></div><div class="ui_resize"></div></div></td></tr></tbody></table></td><td class="ui_border r1d2"></td></tr><tr><td class="ui_border r2d0"></td><td class="ui_border r2d1"></td><td class="ui_border r2d2"></td></tr></tbody></table></div></div></body></html>