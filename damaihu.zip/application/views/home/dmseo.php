<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>淘宝SEO_淘宝SEO培训_淘宝优化_大麦户网商互动平台领跑者，接任务赚佣金，发任务赚信誉，让您生意大卖。</title>
<link rel="shortcut icon" href="http://www.idc-hosting.com/favicon.ico">
<meta name="description" content="大麦户seo培训让店铺推广宝贝排名优化-大麦户网商互动平台领跑者,接任务赚佣金,发任务赚信誉,让您生意大卖.">
<meta name="keywords" content="淘宝刷钻,淘宝刷钻平台,淘宝刷信誉,刷信誉,淘宝刷信用,淘宝SEO.">
<link href="/static/css2/main.css" rel="stylesheet" type="text/css">
<link href="/static/css2/jcalendar.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js2/jquery.js"></script><script type="text/javascript" src="/static/js2/common.js"></script>
<!--[if lte IE 6]>
<script type="text/javascript" src="/static/js2/javascript/cn/DD_belatedPNG_0.0.7a.js"></script>
<script type="text/javascript">
DD_belatedPNG.fix('*');
</script>
<![endif]-->
<script type="text/javascript" src="/static/js2/artDialog.js"></script><style type="text/css">* html body{margin:0}.ui_title_icon,.ui_content,.ui_dialog_icon,.ui_btns span{display:inline-block;*zoom:1;*display:inline}.ui_dialog{text-align:left;display:none;position:absolute;top:0;left:-99999em;_overflow:hidden}.ui_dialog table{border:0;margin:0;border-collapse:collapse}.ui_dialog td{padding:0}.ui_title_icon{vertical-align:middle}.ui_title_text{overflow:hidden;cursor:default;-moz-user-select:none;user-select:none}.ui_close{display:block;position:absolute;outline:none}.ui_content_wrap{height:auto;text-align:center}.ui_content{margin:10px;text-align:left}.ui_dialog_icon{vertical-align:middle}.ui_content.ui_iframe{margin:0;*padding:0;display:block;height:100%}.ui_iframe iframe{width:100%;height:100%;border:none;overflow:auto}.ui_bottom{position:relative}.ui_resize{position:absolute;right:0;bottom:0;z-index:1;cursor:nw-resize;_font-size:0}.ui_btns{text-align:right;white-space:nowrap}.ui_btns span{margin:5px 10px}.ui_content em{font-weight:700;font-style:normal;color:#ff5500;}.ui_btns button{cursor:pointer}.ui_overlay{display:none;position:absolute;top:0;left:0;width:100%;height:100%;filter:alpha(opacity=0);opacity:0;_overflow:hidden}.ui_overlay div{height:100%}* html .ui_ie6_select_mask{width:99999em;height:99999em;position:absolute;top:0;left:0;z-index:-1}.ui_move .ui_title_text{cursor:move}html >body .ui_dialog_wrap.ui_fixed .ui_dialog{position:fixed}* html .ui_dialog_wrap.ui_fixed .ui_dialog{fixed:true}* html.ui_ie6_fixed{background:url(*) fixed}* html.ui_ie6_fixed body{height:100%}* html .ui_dialog_wrap.ui_fixed{width:100%;height:100%;position:absolute;left:expression(documentElement.scrollLeft+documentElement.clientWidth-this.offsetWidth);top:expression(documentElement.scrollTop+documentElement.clientHeight-this.offsetHeight)}html.ui_page_lock >body{overflow:hidden}* html.ui_page_lock{overflow:hidden}* html.ui_page_lock select,* html.ui_page_lock .ui_ie6_select_mask{visibility:hidden}html.ui_page_lock >body .ui_dialog_wrap.ui_lock{width:100%;height:100%;position:fixed;top:0;left:0}</style>
<script type="text/javascript" src="/static/js2/Common.js"></script>
<script type="text/javascript">
var webqq = 147898283;
var webnoticeurl = "";
var webnoticetit = "";
</script>
<script type="text/javascript" src="/static/js2/jcalendar.js"></script>
<style type="text/css">
.kd a:hover { text-decoration:underline;}
</style>
<style type="text/css" charset="utf-8">/* See license.txt for terms of usage */
/** reset styling **/
.firebugResetStyles {
    z-index: 2147483646 !important;
    top: 0 !important;
    left: 0 !important;
    display: block !important;
    border: 0 none !important;
    margin: 0 !important;
    padding: 0 !important;
    outline: 0 !important;
    min-width: 0 !important;
    max-width: none !important;
    min-height: 0 !important;
    max-height: none !important;
    position: fixed !important;
    transform: rotate(0deg) !important;
    transform-origin: 50% 50% !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: transparent none !important;
    pointer-events: none !important;
    white-space: normal !important;
}

.firebugBlockBackgroundColor {
    background-color: transparent !important;
}

.firebugResetStyles:before, .firebugResetStyles:after {
    content: "" !important;
}
/**actual styling to be modified by firebug theme**/
.firebugCanvas {
    display: none !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.firebugLayoutBox {
    width: auto !important;
    position: static !important;
}

.firebugLayoutBoxOffset {
    opacity: 0.8 !important;
    position: fixed !important;
}

.firebugLayoutLine {
    opacity: 0.4 !important;
    background-color: #000000 !important;
}

.firebugLayoutLineLeft, .firebugLayoutLineRight {
    width: 1px !important;
    height: 100% !important;
}

.firebugLayoutLineTop, .firebugLayoutLineBottom {
    width: 100% !important;
    height: 1px !important;
}

.firebugLayoutLineTop {
    margin-top: -1px !important;
    border-top: 1px solid #999999 !important;
}

.firebugLayoutLineRight {
    border-right: 1px solid #999999 !important;
}

.firebugLayoutLineBottom {
    border-bottom: 1px solid #999999 !important;
}

.firebugLayoutLineLeft {
    margin-left: -1px !important;
    border-left: 1px solid #999999 !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.firebugLayoutBoxParent {
    border-top: 0 none !important;
    border-right: 1px dashed #E00 !important;
    border-bottom: 1px dashed #E00 !important;
    border-left: 0 none !important;
    position: fixed !important;
    width: auto !important;
}

.firebugRuler{
    position: absolute !important;
}

.firebugRulerH {
    top: -15px !important;
    left: 0 !important;
    width: 100% !important;
    height: 14px !important;
    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%13%88%00%00%00%0E%08%02%00%00%00L%25a%0A%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%04%F8IDATx%DA%EC%DD%D1n%E2%3A%00E%D1%80%F8%FF%EF%E2%AF2%95%D0D4%0E%C1%14%B0%8Fa-%E9%3E%CC%9C%87n%B9%81%A6W0%1C%A6i%9A%E7y%0As8%1CT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AATE9%FE%FCw%3E%9F%AF%2B%2F%BA%97%FDT%1D~K(%5C%9D%D5%EA%1B%5C%86%B5%A9%BDU%B5y%80%ED%AB*%03%FAV9%AB%E1%CEj%E7%82%EF%FB%18%BC%AEJ8%AB%FA'%D2%BEU9%D7U%ECc0%E1%A2r%5DynwVi%CFW%7F%BB%17%7Dy%EACU%CD%0E%F0%FA%3BX%FEbV%FEM%9B%2B%AD%BE%AA%E5%95v%AB%AA%E3E5%DCu%15rV9%07%B5%7F%B5w%FCm%BA%BE%AA%FBY%3D%14%F0%EE%C7%60%0EU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5JU%88%D3%F5%1F%AE%DF%3B%1B%F2%3E%DAUCNa%F92%D02%AC%7Dm%F9%3A%D4%F2%8B6%AE*%BF%5C%C2Ym~9g5%D0Y%95%17%7C%C8c%B0%7C%18%26%9CU%CD%13i%F7%AA%90%B3Z%7D%95%B4%C7%60%E6E%B5%BC%05%B4%FBY%95U%9E%DB%FD%1C%FC%E0%9F%83%7F%BE%17%7DkjMU%E3%03%AC%7CWj%DF%83%9An%BCG%AE%F1%95%96yQ%0Dq%5Dy%00%3Et%B5'%FC6%5DS%95pV%95%01%81%FF'%07%00%00%00%00%00%00%00%00%00%F8x%C7%F0%BE%9COp%5D%C9%7C%AD%E7%E6%EBV%FB%1E%E0(%07%E5%AC%C6%3A%ABi%9C%8F%C6%0E9%AB%C0'%D2%8E%9F%F99%D0E%B5%99%14%F5%0D%CD%7F%24%C6%DEH%B8%E9rV%DFs%DB%D0%F7%00k%FE%1D%84%84%83J%B8%E3%BA%FB%EF%20%84%1C%D7%AD%B0%8E%D7U%C8Y%05%1E%D4t%EF%AD%95Q%BF8w%BF%E9%0A%BF%EB%03%00%00%00%00%00%00%00%00%00%B8vJ%8E%BB%F5%B1u%8Cx%80%E1o%5E%CA9%AB%CB%CB%8E%03%DF%1D%B7T%25%9C%D5(%EFJM8%AB%CC'%D2%B2*%A4s%E7c6%FB%3E%FA%A2%1E%80~%0E%3E%DA%10x%5D%95Uig%15u%15%ED%7C%14%B6%87%A1%3B%FCo8%A8%D8o%D3%ADO%01%EDx%83%1A~%1B%9FpP%A3%DC%C6'%9C%95gK%00%00%00%00%00%00%00%00%00%20%D9%C9%11%D0%C0%40%AF%3F%EE%EE%92%94%D6%16X%B5%BCMH%15%2F%BF%D4%A7%C87%F1%8E%F2%81%AE%AAvzr%DA2%ABV%17%7C%E63%83%E7I%DC%C6%0Bs%1B%EF6%1E%00%00%00%00%00%00%00%00%00%80cr%9CW%FF%7F%C6%01%0E%F1%CE%A5%84%B3%CA%BC%E0%CB%AA%84%CE%F9%BF)%EC%13%08WU%AE%AB%B1%AE%2BO%EC%8E%CBYe%FE%8CN%ABr%5Dy%60~%CFA%0D%F4%AE%D4%BE%C75%CA%EDVB%EA(%B7%F1%09g%E5%D9%12%00%00%00%00%00%00%00%00%00H%F6%EB%13S%E7y%5E%5E%FB%98%F0%22%D1%B2'%A7%F0%92%B1%BC%24z3%AC%7Dm%60%D5%92%B4%7CEUO%5E%F0%AA*%3BU%B9%AE%3E%A0j%94%07%A0%C7%A0%AB%FD%B5%3F%A0%F7%03T%3Dy%D7%F7%D6%D4%C0%AAU%D2%E6%DFt%3F%A8%CC%AA%F2%86%B9%D7%F5%1F%18%E6%01%F8%CC%D5%9E%F0%F3z%88%AA%90%EF%20%00%00%00%00%00%00%00%00%00%C0%A6%D3%EA%CFi%AFb%2C%7BB%0A%2B%C3%1A%D7%06V%D5%07%A8r%5D%3D%D9%A6%CAu%F5%25%CF%A2%99%97zNX%60%95%AB%5DUZ%D5%FBR%03%AB%1C%D4k%9F%3F%BB%5C%FF%81a%AE%AB'%7F%F3%EA%FE%F3z%94%AA%D8%DF%5B%01%00%00%00%00%00%00%00%00%00%8E%FB%F3%F2%B1%1B%8DWU%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*UiU%C7%BBe%E7%F3%B9%CB%AAJ%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5J%95*U%AAT%A9R%A5*%AAj%FD%C6%D4%5Eo%90%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5%86%AF%1B%9F%98%DA%EBm%BBV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%ADV%AB%D5j%B5Z%AD%D6%E4%F58%01%00%00%00%00%00%00%00%00%00%00%00%00%00%40%85%7F%02%0C%008%C2%D0H%16j%8FX%00%00%00%00IEND%AEB%60%82") repeat-x !important;
    border-top: 1px solid #BBBBBB !important;
    border-right: 1px dashed #BBBBBB !important;
    border-bottom: 1px solid #000000 !important;
}

.firebugRulerV {
    top: 0 !important;
    left: -15px !important;
    width: 14px !important;
    height: 100% !important;
    background: url("data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0E%00%00%13%88%08%02%00%00%00%0E%F5%CB%10%00%00%00%04gAMA%00%00%D6%D8%D4OX2%00%00%00%19tEXtSoftware%00Adobe%20ImageReadyq%C9e%3C%00%00%06~IDATx%DA%EC%DD%D1v%A20%14%40Qt%F1%FF%FF%E4%97%D9%07%3BT%19%92%DC%40(%90%EEy%9A5%CB%B6%E8%F6%9Ac%A4%CC0%84%FF%DC%9E%CF%E7%E3%F1%88%DE4%F8%5D%C7%9F%2F%BA%DD%5E%7FI%7D%F18%DDn%BA%C5%FB%DF%97%BFk%F2%10%FF%FD%B4%F2M%A7%FB%FD%FD%B3%22%07p%8F%3F%AE%E3%F4S%8A%8F%40%EEq%9D%BE8D%F0%0EY%A1Uq%B7%EA%1F%81%88V%E8X%3F%B4%CEy%B7h%D1%A2E%EBohU%FC%D9%AF2fO%8BBeD%BE%F7X%0C%97%A4%D6b7%2Ck%A5%12%E3%9B%60v%B7r%C7%1AI%8C%BD%2B%23r%00c0%B2v%9B%AD%CA%26%0C%1Ek%05A%FD%93%D0%2B%A1u%8B%16-%95q%5Ce%DCSO%8E%E4M%23%8B%F7%C2%FE%40%BB%BD%8C%FC%8A%B5V%EBu%40%F9%3B%A72%FA%AE%8C%D4%01%CC%B5%DA%13%9CB%AB%E2I%18%24%B0n%A9%0CZ*Ce%9C%A22%8E%D8NJ%1E%EB%FF%8F%AE%CAP%19*%C3%BAEKe%AC%D1%AAX%8C*%DEH%8F%C5W%A1e%AD%D4%B7%5C%5B%19%C5%DB%0D%EF%9F%19%1D%7B%5E%86%BD%0C%95%A12%AC%5B*%83%96%CAP%19%F62T%86%CAP%19*%83%96%CA%B8Xe%BC%FE)T%19%A1%17xg%7F%DA%CBP%19*%C3%BA%A52T%86%CAP%19%F62T%86%CA%B0n%A9%0CZ%1DV%C6%3D%F3%FCH%DE%B4%B8~%7F%5CZc%F1%D6%1F%AF%84%F9%0F6%E6%EBVt9%0E~%BEr%AF%23%B0%97%A12T%86%CAP%19%B4T%86%CA%B8Re%D8%CBP%19*%C3%BA%A52huX%19%AE%CA%E5%BC%0C%7B%19*CeX%B7h%A9%0C%95%E1%BC%0C%7B%19*CeX%B7T%06%AD%CB%5E%95%2B%BF.%8F%C5%97%D5%E4%7B%EE%82%D6%FB%CF-%9C%FD%B9%CF%3By%7B%19%F62T%86%CA%B0n%D1R%19*%A3%D3%CA%B0%97%A12T%86uKe%D0%EA%B02*%3F1%99%5DB%2B%A4%B5%F8%3A%7C%BA%2B%8Co%7D%5C%EDe%A8%0C%95a%DDR%19%B4T%C66%82fA%B2%ED%DA%9FC%FC%17GZ%06%C9%E1%B3%E5%2C%1A%9FoiB%EB%96%CA%A0%D5qe4%7B%7D%FD%85%F7%5B%ED_%E0s%07%F0k%951%ECr%0D%B5C%D7-g%D1%A8%0C%EB%96%CA%A0%A52T%C6)*%C3%5E%86%CAP%19%D6-%95A%EB*%95q%F8%BB%E3%F9%AB%F6%E21%ACZ%B7%22%B7%9B%3F%02%85%CB%A2%5B%B7%BA%5E%B7%9C%97%E1%BC%0C%EB%16-%95%A12z%AC%0C%BFc%A22T%86uKe%D0%EA%B02V%DD%AD%8A%2B%8CWhe%5E%AF%CF%F5%3B%26%CE%CBh%5C%19%CE%CB%B0%F3%A4%095%A1%CAP%19*Ce%A8%0C%3BO*Ce%A8%0C%95%A12%3A%AD%8C%0A%82%7B%F0v%1F%2FD%A9%5B%9F%EE%EA%26%AF%03%CA%DF9%7B%19*Ce%A8%0C%95%A12T%86%CA%B8Ze%D8%CBP%19*Ce%A8%0C%95%D1ae%EC%F7%89I%E1%B4%D7M%D7P%8BjU%5C%BB%3E%F2%20%D8%CBP%19*Ce%A8%0C%95%A12T%C6%D5*%C3%5E%86%CAP%19*Ce%B4O%07%7B%F0W%7Bw%1C%7C%1A%8C%B3%3B%D1%EE%AA%5C%D6-%EBV%83%80%5E%D0%CA%10%5CU%2BD%E07YU%86%CAP%19*%E3%9A%95%91%D9%A0%C8%AD%5B%EDv%9E%82%FFKOee%E4%8FUe%A8%0C%95%A12T%C6%1F%A9%8C%C8%3D%5B%A5%15%FD%14%22r%E7B%9F%17l%F8%BF%ED%EAf%2B%7F%CF%ECe%D8%CBP%19*Ce%A8%0C%95%E1%93~%7B%19%F62T%86%CAP%19*Ce%A8%0C%E7%13%DA%CBP%19*Ce%A8%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4h%A9%0C%B3E%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%A9%0CZf%8B%16-Z%B4h%D1R%19f%8B%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1R%19%B4%CC%16-Z%B4h%D1%A2%A52%CC%16-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2%A52h%99-Z%B4h%D1%A2EKe%98-Z%B4h%D1%A2EKe%D02%5B%B4h%D1%A2EKe%D02%5B%B4h%D1%A2E%8B%96%CA0%5B%B4h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%96%CA%A0e%B6h%D1%A2E%8B%16-%95a%B6h%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-%95A%CBl%D1%A2E%8B%16-Z*%C3l%D1%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z*%83%96%D9%A2E%8B%16-Z%B4T%86%D9%A2E%8B%16-Z%B4T%06-%B3E%8B%16-Z%B4%AE%A4%F5%25%C0%00%DE%BF%5C'%0F%DA%B8q%00%00%00%00IEND%AEB%60%82") repeat-y !important;
    border-left: 1px solid #BBBBBB !important;
    border-right: 1px solid #000000 !important;
    border-bottom: 1px dashed #BBBBBB !important;
}

.overflowRulerX > .firebugRulerV {
    left: 0 !important;
}

.overflowRulerY > .firebugRulerH {
    top: 0 !important;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
.fbProxyElement {
    position: fixed !important;
    pointer-events: auto !important;
}
</style></head>

<body>
	<!--头部开始-->
	<style>
#dmh_head {background: #EFF6FE;border-bottom: 1px solid #DBEBFA;height: 25px;left: 0;position: fixed;width: 100%;z-index: 9999;}
#dmh_head .kd {position: relative;}
#dmh_head .kd, #m_banner .kd {margin: 0 auto;width: 980px;}
#dmh_head .kmain {position: absolute;top: 0;width: 898px;}
#dmh_head .hy {float: left;}
#dmh_head .kd .dmhtel {background: url("/static/image2/dmhtel.png") no-repeat scroll 7px center transparent;float: left;height: 22px;padding-left: 25px;width: 36px;}
#dmh_head .hy a {color: #1595DE;margin: 0 5px;}
#dmh_head .hy a.col3 {color: #666666;margin: 0 10px;}
#dmh_head .top_btn {color: #1595DE;float: right;}
#dmh_head .top_btn a {color: #1595DE;margin: 0 10px;}
#dmh_head .menu_qq {text-align: right;}
#dmh_head .menu_qq a {color: #1595DE;font-family: Tahoma,​Helvetica,​Arial,​宋体;font-size: 12px;padding-left: 26px;}
#dmh_head .menu_qq .qq_help {background: url("/static/image2/tx_ico.gif") no-repeat scroll 0 -958px transparent;}
#dmh_head .help_down {background: none repeat scroll 0 0 #FFFFFF;border: 3px solid #7FC3F4;padding: 0 10px;position: absolute;right: 0;top: 25px;width: 500px;z-index: 9999;height:255px;*height:270px;}
#dmh_head .help_down ul {border-bottom: 1px dashed #DDDDDD;padding-left: 10px;padding-top: 6px;}
#dmh_head a:hover{color:#FE5500}
#dmh_head b{color:#FE5500}
#dmh_head .quick-menu {margin: 2px 0 0 0;}
#dmh_head .quick-menu li.menu-item {padding: 1px 0 0;position: relative;margin-right: 1px;}
#dmh_head .quick-menu li {background-position: right 6px;float: left;margin-left: -1px;background:none;border:1px solid #EFF6FE;}
#menu-0{display:none;}
#dmh_head .menu {position: relative;float: left;line-height: 140%;}
#dmh_head .menu-hd {cursor: pointer;height: 20px;padding: 1px 22px 0 16px;position: relative;z-index: 10002;}
#dmh_head .menu-hd b {border-color: #666666 #EFF6FE #EFF6FE;border-style: solid;border-width: 4px;font-size: 0;height: 0;line-height: 0;position: absolute;right: 10px;top: 6px;transition: transform 0.2s ease-in 0s;width: 0;}
/*针对客服帮助*/
#dmh_head .help_down {
    background: none repeat scroll 0 0 #FFFFFF;
    border: 3px solid #7FC3F4;
    height:195px;
    padding: 0 10px;
    position: absolute;
    right: 0;
    top: 25px;
    width: 500px;
    z-index: 9999;
}
</style>
<div id="dmh_head">
	<div class="kd">
	    <div class="kmain">
			<div class="hy">


				<div style="float:left;">

					<span style="color:#666">亲，欢迎来到{webName}！请</span>
					<a href="http://www.idc-hosting.com/user/login/" class="chengse">登录</a>
					<a href="http://www.idc-hosting.com/user/reg/" class="lvse">免费注册</a>
				</div>

			</div>
			<div class="top_btn">

				<ul class="quick-menu">
					<a href="http://www.idc-hosting.com/user/reg/" style="float:left;margin-top: -1px;"><b>新手帮助</b></a>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/html/express/" style="width:50px;margin:0;" class="menu-hd" tabindex="0">帮助中心<b></b></a>
							<div style="width: 105px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/diagram/index/">图文实录教程</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskout/">我是发布方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/taskin/">我是接手方</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/bilking/">防骗小课堂</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<li class="menu-item">
						<div class="menu">
							<a href="http://www.idc-hosting.com/help/selfservice/" style="width:52px;margin:0;" class="menu-hd" tabindex="0">账号设置<b></b></a>
							<div style="width: 90px;line-height:1.7;" class="menu-bd" id="menu-0">
							  <div style="padding:8px 5px;" class="menu-bd-panel">
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回密码</a>
								  <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/#moreservice">找回操作码</a>
								   <a rel="nofollow" target="_top" href="http://www.idc-hosting.com/help/selfservice/">更多操作</a>
							  </div>
							</div>
						</div>
					</li>
					<li style="margin-top: -2px;">|</li>
					<a href="http://www.idc-hosting.com/rank.html" style="margin-top: -2px;">排行榜</a>
				</ul>

			</div>
		</div>

		<div class="menu_qq">
			<a class="qq_help" onmouseover="showcsqq();" href="javascript:;">客服帮助</a>
		</div>
		<div id="service_qq" class="help_down" style="display:none;"></div>
	</div>
</div>
<script>
$(function(){
	$(".menu-item .menu-hd").hover(function(){
		$(this).next('#menu-0').show();
		$(this).children('b').css({borderColor:'#666666 white white',transform:'rotate(180deg',transformOrigin:'50% 30% 0px'});
		$(this).parents(".menu-item").css({background:'rgb(255, 255, 255)',border:'1px solid rgb(191, 191, 191)'})
	});
	$(".menu-item .menu").mouseleave(function(){
		$(this).children('#menu-0').hide();
		$(this).children('.menu-hd').children('b').css({borderColor:'#666666 #EFF6FE #EFF6FE',transform:'none',transformOrigin:'none'});
		$(this).parent(".menu-item").css({background:'none',border:'1px solid #EFF6FE'})
	});
})
</script>
	<!--logo开始-->
	<div id="m_logo">
		<a href="http://www.idc-hosting.com/" class="logo"><img src="/static/image2/head_logo.png" alt="大麦户_淘宝刷信誉"></a>
		<a href="http://www.idc-hosting.com/fuwu/video/" class="gg" target="_blank"><img src="/static/image2/ddd.gif" alt="视频教程" title="视频教程" border="0" height="67" width="689"></a>
	</div>
	<!--菜单开始-->
<div id="m_menu" style="position:relative;">
	<div class="menu_nav">
		<div class="m_menu_nav">
			<ul>
			<?php include "menu.php"; ?>
			</ul>
		</div>
	</div>
</div>
<script type="text/javascript" src="/static/js2/service.js"></script>
<style>
	.xuanchuan-content {width:960px; margin:0 auto; font-family:微软雅黑; background:#eee; }
	.xuanchuan-top {background:url(/static/image2/xuanchuan-1.jpg) repeat-x; height:44px; line-height:47px; text-align:center;}
	.xuanchuan-tab {background:url(/static/image2/xuanchuan-3.jpg) repeat-x; height:75px; line-height:40px; font-size:14px;}
	.xuanchuan-tab a {color:#fff; margin-left:15px;}
	.xuanchuan-zhuti {background:#eeeeee;}
	.xuanchuan-neirong {background:url(/static/image2/xuanchuan-4.jpg) no-repeat right;}
	.xuanchuan-neirong {padding-bottom:30px;}
	.xuanchuan-n-part {width:650px; padding-top:30px; padding-left:30px;}
	.xuanchuan-n-part h2 {background:#efdfd7; color:#f05306; height:40px; line-height:40px; font-weight:bold; padding-left:15px;}
	.xuanchuan-n-part h2 span {font-size:16px;}
	.xuanchuan-n-part p {margin-left:15px; line-height:20px; font-size:13px; margin-top:15px; margin-bottom:10px;}
	.xuanchuan-id-tit {background:url(/static/image2/xuanchuan-5.jpg) no-repeat; width:960px; height:41px; color:#fff; text-align:center; font-weight:bold; font-size:16px; line-height:41px;}
	.xuanchuan-wenda {font-size:14px; padding:30px;}
</style>
<script language="JavaScript" type="text/javascript">
function firm()
{
    if(confirm("您确认购买?"))
    {
         document.seoform.submit();
     }
    else
    {
     }
}

</script>
<!--main star-->
 <div id="content">
			<div class="xuanchuan-content">
		<div class="xuanchuan-top">日均成交量：10笔以下&nbsp;&nbsp;&nbsp;&nbsp;适合店铺类型：不限&nbsp;&nbsp;&nbsp;&nbsp;适合商家雇员数量：1-3&nbsp;&nbsp;&nbsp;&nbsp;适合店铺行业：不限    </div>
		<div><form action="/DmSEO/Case/" name="seoform" method="post" onsubmit="return false;"><input name="hash2" value="NzZlMUZqNmZvaXRJaVBEdTI1WVBYd3dOT0FBR2kvdDlPZmxkL2pTREg2VVdzRVExdEdoT1RwcktBYzkzQ2gwVlpnK1hqRGhzVDVwdUxFSDlmdw==" type="hidden"></form><img onclick="firm();" src="/static/image2/xuanchuan-2.jpg" style="cursor:pointer;"></div>
		<div class="xuanchuan-tab"><a href="http://www.idc-hosting.com/DmSEO/">服务详情</a>   <a href="http://www.idc-hosting.com/DmSEO/Case/">成功案例</a>  <a href="http://www.idc-hosting.com/bbs/seo/" target="_blank">SEO论坛</a>  <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1020130386&amp;site=qq&amp;menu=yes"><font color="#000000">讲师QQ：<img src="/static/image2/pa.gif" alt="点击这里给我发消息" title="点击这里给我发消息" border="0">1020130386   请猛击我吧~</font></a></div>
		<div class="xuanchuan-zhuti">
			<div class="xuanchuan-neirong">
				<div class="xuanchuan-n-part">
					<h2><span>淘宝SEO优化</span> | The first point</h2>
					<p>淘宝优化是指通过对淘宝店铺各方面进行优化设置，达到店铺商品关键词 排名靠前、商品曝光率和点击率增加来提高店铺流量，同时提高进店顾客的购物体验，进而提高商品转化率。</p>
				</div>
				<div class="xuanchuan-n-part">
					<h2><span>影响淘宝排名的几大因素</span> | The Two point</h2>
					<p>在这里我们为大家详细解读淘宝宝贝排名规则，根据规则来优化我们的宝贝。<br>
影响排名的因素有：<br>
宝贝标题包含关键词<br>
宝贝属性完整正确<br>
宝贝上架时间<br>
宝贝厨窗推荐<br>
宝贝加入消保<br>
店铺信誉<br>
设置宝贝促销</p>
				</div>
				<div class="xuanchuan-n-part">
					<h2><span>你还在为流量苦恼没有生意吗</span> | The Three point</h2>
					<p>你还在为宝贝人气苦恼没有生意吗<br>
你还在为如何提高销量而苦恼吗<br>
你还在为宝贝降权而苦恼吗<br>
在这里我们为大家详细解读淘宝宝贝排名规则，根据规则来优化我们的宝贝。<br>
一对一指导 实践指导用户店铺。<br>
</p>
				</div>
			</div>
		</div>
		<div class="xuanchuan-id-part">
			<div class="xuanchuan-id-tit">大部分网店存在的问题</div>
			<p style="text-align:center;"><img src="/static/image2/xuanchuan-6.jpg"></p>
		</div>
		<div class="xuanchuan-id-part">
			<div class="xuanchuan-id-tit">参加培训可以为你带来什么</div>
			<p style="text-align:center;"><img src="/static/image2/xuanchuan-7.jpg"></p>
		</div>
		<div class="xuanchuan-id-part">
			<div class="xuanchuan-id-tit">选择我们的理由</div>
			<p style="text-align:center;"><img src="/static/image2/xuanchuan-8.jpg"></p>
		</div>
		<div class="xuanchuan-id-part">
			<div class="xuanchuan-id-tit">常见问题</div>
			<div class="xuanchuan-wenda">


				<p style="color:#e76900;">小飞：我们中小卖家真的能通过淘宝培训获得成功吗？</p>
				<p>解答：淘宝已经不是之前的农贸市场了，不是你开个店放那就可以有生意的，也有很多中小卖家努力了很久没有成效，或者进步很慢，这个都是普遍
现象，不过我们分析原因可以知道，他们大多都是自己埋头研究，自己去摸爬滚打。而我们淘宝培训班就像是一艘开往淘宝成功大道的邮轮，搭载上这班顺风的船绝
对是会让你走捷径。</p>

					<p>&nbsp;</p>
				<p style="color:#e76900;">小飞：那你的培训主要适合哪一类的人？</p>
				<p>解答：1.淘宝新手，对淘宝的很多基本规则不了解的。<br>
      2.懂一点点淘宝但是又一直没有生意的朋友<br>
      3.懂淘宝，但是还是很迷茫，一直没有什么销量。<br>
      4.处在淘宝的瓶颈期。想再让流量和销量进一步提高。
</p>
			<p>&nbsp;</p>

				<p style="color:#e76900;">小飞：这是否难学？肯定能学会吗？</p>
				<p>解答：我们从淘宝基础的讲起，每周还是专门的答疑课程，专门解答各位学员遇到的各种问题，我们讲课都会以案例分析的形式给大家举例说明我们
所教授的方法和技巧，我只能说，你可以参加免费试听，或者接受3天试学，来判断一下这个对自己的难度。同时，我们提供了学不会无限复训。</p>
						<p>&nbsp;</p>
				<p style="color:#e76900;">小飞：成为学员如何学习？</p>
				<p>解答：成为学员后，我们的学习和培新包含多种方式：每周都有YY语音课，QQ群交流，论坛学习，私人咨询。<br>
QQ群交流气氛浓厚，有任何问题都可以再群里得到解答。认真学习论坛的知识可以让你对淘宝推广优化有一个非常了解清晰的概念。有任何的疑问可以联系我们客服。
</p>
							<p>&nbsp;</p>
				<p style="color:#e76900;">小飞：现在淘宝上开店的人那么多，学习淘宝推广优化有用吗?</p>
				<p>解答：现在虽然淘宝卖家非常的多，但是懂得用淘宝SEO优化店铺获得免费流量的人很少很少，很多新手卖家都没有淘宝SEO优化这个概念。根
据统计，到现在为止，800万的淘宝卖家，还不到0.1%的人能掌握这优化技巧！我们论坛很多VIP学员参加培训后只简单的优化一下标题类目和宝贝属性就
可以获得非常明显的效果，流量一下子翻好几倍。</p>
							<p>&nbsp;</p>

			</div>
		</div>


	</div>

</div>
<div class="cle"></div>
<div id="footer">
  <p><span class="chengse">官方QQ群：<span class="web_qq">147898283</span><span style="display:none;" class="quick_qq"><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img src="/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群" border="0"></a></span></span> （加群请注明大麦户）</p>
		<p class="lanse"><a href="http://www.idc-hosting.com/info/aboutus.html">关于我们</a>|<a href="http://www.idc-hosting.com/info/contactus.html">联系我们</a>|<a href="http://www.idc-hosting.com/info/duty.html">服务条款</a>|<a href="http://www.idc-hosting.com/info/map.html">网站地图</a></p>
  <p class="lanse">客户服务热线：4006079159   Copyright © 2012-2020 Damaihu.com All RightsReserved    大麦户版权所有 <a href="http://www.miitbeian.gov.cn/" target="_blank">粤ICP备13037934号</a>
</p>
</div>
<script type="text/javascript">
var webnoticeurl = "";
var webnoticetit = "";
var quick_qq = '<a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=cdbc3ca9a295239fffa965afad3f5f2b3b675a112ed342065d9f12ca992636be"><img border="0" src="http://pub.idqqimg.com/wpa/static/image2/group.png" alt="大麦户刷钻平台24群" title="大麦户刷钻平台24群"></a>';
$('.web_qq').hover(function(){
    $('.quick_qq').show();
});
</script>

<div id="" class="ui_dialog_wrap"><div style="" class="ui_dialog"><table class=""><tbody><tr><td class="ui_border r0d0"></td><td class="ui_border r0d1"></td><td class="ui_border r0d2"></td></tr><tr><td class="ui_border r1d0"></td><td><table class="ui_dialog_main"><tbody><tr><td class="ui_title_wrap"><div class="ui_title"><div class="ui_title_text"></div><a href="javascript:void(0)" class="ui_close">×</a></div></td></tr><tr><td style="width: auto; height: auto;" class="ui_content_wrap"><div id="" class="ui_content "></div></td></tr><tr><td class="ui_bottom_wrap"><div class="ui_bottom"><div class="ui_btns"></div><div class="ui_resize"></div></div></td></tr></tbody></table></td><td class="ui_border r1d2"></td></tr><tr><td class="ui_border r2d0"></td><td class="ui_border r2d1"></td><td class="ui_border r2d2"></td></tr></tbody></table></div></div></body></html>