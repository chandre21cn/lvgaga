<div class="tico menu">
	<a class="nov" title="单个任务商品" href="/home/Dating/publish">单个任务商品</a>
	<a title="来路任务" href="/home/Dating/lailuTask">来路任务</a>
	<a title="套餐任务" href="/home/Dating/mealTask">套餐任务</a>
	<a title="购物车任务" href="/home/Dating/shopCartTask">购物车任务</a>
	<a title="任务模版" href="#publish/taskTemplate">任务模版</a>
	<a title="已发任务" href="#outTask">已发任务</a>
</div>