<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>会员中心-大麦户网商互动平台领跑者，接任务赚佣金，发任务赚信誉，让您生意大卖。</title>
    <meta name="description" content="大麦户信誉平台为为那些零信誉低销量的掌柜提供解决方案,新手快速提升信誉,发任务提升信誉,就选大麦户。" />
    <meta name="keywords" content="会员中心" />
    <link rel="shortcut icon" href="favicon.ico">
	<link rel="stylesheet" type="text/css" href="/wanjia/static/css/main.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/static/css/twitter.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_index.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_seckill.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_express.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_black.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_payment.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_paydetails.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_rechange.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_userData.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_thread.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_message.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_userjob.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_specialty.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_ensure.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_complain.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_vip.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_topup.css">
	<link rel="stylesheet" type="text/css" href="/wanjia/member/css/user_autoam.css">
    <script type="text/javascript" src="/wanjia/static/js/jquery-1.9.1.js"></script>
    <script type="text/javascript" src="/wanjia/static/js/artDialog.js"></script>
	<script type="text/javascript" src="/wanjia/static/js/header.js"></script>
</head>
<body>