<?php include('index_header.php'); ?>

	<link rel="stylesheet" type="text/css" href="/wanjia/static/css/main.css">

<style>
#wrap{ margin: 0 auto;width: 1000px;}
.sq_vipbg{ background: url(/wanjia/static/images/info/vip_1.png) no-repeat ;height: 324px;margin: 15px auto 0;position: relative;width: 983px;}
.sqvip_btn{ background: url(/wanjia/static/images/info/vip_1.png) no-repeat -2px -340px;display: block;height: 50px;left: 716px;position: absolute;top: 147px;width: 125px;}
.sqvip_bk{ border-collapse: collapse;margin: 0 auto 20px;}
.sqvip_bk tr td{ border: 1px solid #A0D2EC;}
.hongs{ color: #EB0F0F;}
</style>

<div id="wrap">
		<div class="sq_vipbg"><a target="_blank" class="sqvip_btn" href="/BuyPoint/"></a></div>
	     <table width="983" cellspacing="0" cellpadding="0" border="0" align="center" class="sqvip_bk">
               <tbody><tr>
                    <td height="31" align="center"><strong>对应积分</strong></td>
                    <td align="center">0</td>
                    <td align="center">1-100</td>
                    <td align="center">101-1000</td>
                    <td align="center">1001-5000</td>
                    <td align="center">5001</td>
                    <td align="center" class="hongse">无要求</td>
                    <td align="center" class="hongse">无要求</td>
                    <td align="center" class="hongse">无要求</td>
               </tr>
          	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>任务排名靠前</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">无</td>
			            <td width="108" bgcolor="eef9ff" align="center">无</td>
			            <td width="101" bgcolor="eef9ff" align="center">无</td>
			            <td width="119" bgcolor="eef9ff" align="center">无</td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>提现优先处理</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">绑定掌柜数量</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							2个
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							2个
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							3个
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							4个
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							6个
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							10个
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							20个
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							30个
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">快递单号</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							有限制     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							有限制     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							有限制     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							有限制     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							有限制     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">可保存模版数量</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							3
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							3
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							4
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							5
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							6
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							9
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							15
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							30
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>申述优先解决</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>更酷VIP标志</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>客服优先服务</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>任务复制</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							是     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>快速积分</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							1.2倍     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							1.5倍     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							1.8倍     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>同时接任务数</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							1
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							20
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							40
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							70
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							100
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							120
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							160
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							300
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>同时发任务数</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							5
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							15
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							30
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							60
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							100
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							200
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							300
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							10000
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">每日提现次数</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							2
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							2
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							2
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							3
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							3
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							3
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							3
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>任务消耗比例</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0%
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							15%
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							15%
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							15%
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							10%
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							10%
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							10%
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							10%
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>免费短信</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							0     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							0     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							0     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							0     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							30条/月     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							50条/月     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							100条/月     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>发送短信价格</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0.1元
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							0.1元
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							0.1元
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							0.1元
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							0.1元
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.09元
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.08元
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.07元
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">星星回收价格</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0.3元
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							0.3元
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							0.31元
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							0.32元
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							0.33元
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.33元
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.34元
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.35元
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">绑定买号数量</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							5
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							20
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							50
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							100
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							200
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							300
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							500
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							800
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">推广用户提成</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							2%
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							2%
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							2%
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							2%
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							2%
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							3%
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							3%
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							4%
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>客服评价次数</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							2次/月 
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							2次/月 
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							2次/月 
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							2次/月 
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							2次/月 
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							2次/月 
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							2次/月 
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							2次/月 
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>买号黑名单个数</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							20
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							24
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							28
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							32
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							50
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							80
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							160
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							320
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>用户黑名单个数</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							6
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							8
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							10
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							12
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							24
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							50
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							100
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							200
     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         					
         					<strong style="color:#EB0F0F;">快递单号软件</strong>
         				         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							试用     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							试用     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							试用     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							试用     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							试用     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>查看买号IP</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							无     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							无限制     									            </td>
         			</tr>
         	         			<tr>
         				<td width="162" height="31" bgcolor="eef9ff" align="center">
         				     						<strong>网银充值手续费</strong>
     					         				</td>
			            <td width="126" bgcolor="eef9ff" align="center">
			            	     							0.5%
     									            </td>
			            <td width="108" bgcolor="eef9ff" align="center">
			            	     							0.5%
     									            </td>
			            <td width="101" bgcolor="eef9ff" align="center">
			            	     							0.5%
     									            </td>
			            <td width="119" bgcolor="eef9ff" align="center">
			            	     							0.5%
     									            </td>
			            <td width="109" bgcolor="eef9ff" align="center">
			            	     							0.5%
     									            </td>
			            <td width="87" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.4%
     									            </td>
			            <td width="79" bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.3%
     									            </td>
			            <td bgcolor="eef9ff" align="center" class="hongse">
			            	     							0.2%
     									            </td>
         			</tr>
         	         	<tr>
	            <td height="31" bgcolor="#EEF9FF" align="center"><strong>费用</strong></td>
	            <td bgcolor="#EEF9FF" align="center">免费</td>
	            <td bgcolor="#EEF9FF" align="center">免费</td>
	            <td bgcolor="#EEF9FF" align="center">免费</td>
	            <td bgcolor="#EEF9FF" align="center">免费</td>
	            <td bgcolor="#EEF9FF" align="center">免费</td>
	            <td bgcolor="#EEF9FF" align="center" class="hongse">29元/月</td>
	            <td bgcolor="#EEF9FF" align="center" class="hongse">49元/月 </td>
	            <td bgcolor="#EEF9FF" align="center" class="hongse">99元/月 </td>
	          </tr>
        </tbody></table>

</div>


<?php include('index_footer.php'); ?>