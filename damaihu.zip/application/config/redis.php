<?php
$config['ip']='127.0.0.1';
$config['port']=6379;