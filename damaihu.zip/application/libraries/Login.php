<?php
if (! defined ( 'BASEPATH' ))exit ( 'No direct script access allowed' );

class Login
{
	public function LoginIn($params)
	{
	}

	public function AjaxLogin()
	{
		if($this->input->post()){

		}
	}

	public function LoginOut()
	{
	}
}