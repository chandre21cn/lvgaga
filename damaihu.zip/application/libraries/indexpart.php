<?php
class Indexpart
{
	public function Happend()
	{

	}

	public function Notice()
	{
	}

	public function NewSeller()
	{
	}
}