<?php 
 return array (
  'asd' => 232,
) ?>